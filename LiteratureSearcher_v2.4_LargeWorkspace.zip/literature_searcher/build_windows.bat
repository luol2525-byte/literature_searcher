﻿@echo off
setlocal
cd /d "%~dp0"

rem ---------------------------------------------------------
rem Literature Searcher - Windows EXE Builder
rem This script deliberately ignores stale/broken proxy settings
rem for pip only. It does NOT modify your permanent Windows settings.
rem ---------------------------------------------------------

echo =====================================================
echo  Literature Searcher - Windows EXE Builder (Proxy Safe)
echo =====================================================

where py >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python launcher "py" was not found.
    echo Install Python 3.11 or 3.12 from https://www.python.org/downloads/windows/
    echo During installation, enable "Add python.exe to PATH".
    pause
    exit /b 1
)

rem Ignore environment proxy variables for this build process only.
set "HTTP_PROXY="
set "HTTPS_PROXY="
set "ALL_PROXY="
set "FTP_PROXY="
set "PIP_PROXY="
set "http_proxy="
set "https_proxy="
set "all_proxy="
set "ftp_proxy="
set "pip_proxy="

rem NUL is os.devnull on Windows. This makes pip ignore global/user/site
rem pip.ini files that may contain a dead proxy or obsolete index URL.
set "PIP_CONFIG_FILE=NUL"

if not exist ".venv\Scripts\python.exe" (
    echo [1/5] Creating virtual environment...
    py -3 -m venv .venv
    if errorlevel 1 goto :error
)

call ".venv\Scripts\activate.bat"

echo [2/5] Checking Python and pip...
python --version
python -m pip --version
if errorlevel 1 goto :error

echo [3/5] Installing dependencies from official PyPI...
python -m pip install --disable-pip-version-check --retries 2 --timeout 25 ^
  --index-url https://pypi.org/simple -r requirements.txt
if errorlevel 1 (
    echo.
    echo [WARN] Official PyPI failed. Trying Tsinghua PyPI mirror...
    python -m pip install --disable-pip-version-check --retries 2 --timeout 25 ^
      --index-url https://pypi.tuna.tsinghua.edu.cn/simple -r requirements.txt
    if errorlevel 1 goto :network_error
)

echo [4/5] Building single-file Windows EXE...
python -m PyInstaller --noconfirm --clean --onefile --windowed ^
  --name "LiteratureSearcher" ^
  --hidden-import tkinter ^
  literature_searcher.py
if errorlevel 1 goto :error

echo [5/5] Done.
echo.
echo EXE: %CD%\dist\LiteratureSearcher.exe
echo You can copy this EXE to another Windows computer.
pause
exit /b 0

:network_error
echo.
echo [ERROR] Dependencies could not be downloaded.
echo.
echo This is a network/proxy/DNS problem, not a missing Requests package.
echo Run the following commands in CMD to diagnose:
echo   py -m pip config debug
echo   set ^| findstr /I "proxy pip_"
echo.
echo If your network REQUIRES a proxy, configure a valid proxy instead of bypassing it.
echo See README_CN.md section "pip / proxy troubleshooting".
pause
exit /b 2

:error
echo.
echo [ERROR] Build failed. See the messages above.
pause
exit /b 1
