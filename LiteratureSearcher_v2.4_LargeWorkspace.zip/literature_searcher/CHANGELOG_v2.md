# v2.0 change log

- Added Boolean query parser: AND / OR / NOT / parentheses / quoted phrases.
- Preserves chemistry parentheses such as Ni(OH)2.
- Added Web of Science Starter API.
- Added optional Google Scholar structured search through SerpAPI.
- Added browser-assisted Google Scholar, Baidu Scholar, Bing Academic and X-MOL search entry points.
- Added abstracts, citation counts, OA/PDF links, JIF and local relevance score.
- Added Unpaywall DOI enrichment.
- Added official JCR JIF enrichment through Web of Science Journals API.
- Added local xlsx/csv journal impact-factor mapping.
- Added journal whitelist and aliases for Nature, Science, JACS, Angew and ACS Catalysis.
- Added exact/wildcard journal matching.
- Added sorting by relevance, year, citations and JIF.
- Expanded Excel export to 14 fields.
