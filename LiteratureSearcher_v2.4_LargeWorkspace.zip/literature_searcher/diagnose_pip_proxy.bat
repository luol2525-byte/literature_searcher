﻿@echo off
setlocal
cd /d "%~dp0"

echo =====================================================
echo  Literature Searcher - pip/proxy diagnostics
echo =====================================================
echo.
echo [Python]
where py
py --version
echo.
echo [pip]
py -m pip --version
echo.
echo [pip config debug]
py -m pip config debug
echo.
echo [pip config list -v]
py -m pip config list -v
echo.
echo [Proxy-related environment variables]
set | findstr /I "proxy pip_"
echo.
echo No settings were changed by this diagnostic script.
pause
