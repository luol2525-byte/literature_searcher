# Literature Searcher v2.1.0

- 新增中文 ↔ 英文自动互译联合检索，保留 AND/OR/NOT/括号结构。
- 化学式与常见缩写（如 Ni(OH)2、FeNi-LDH、OER）默认不翻译。
- 合并结果时优先使用期刊全称；加入常见期刊简称规范化。
- 新增 Crossref DOI/ISSN 元数据补全期刊全称。
- 摘要不足时可利用 Crossref/OpenAlex DOI 元数据补充更完整摘要。
- 摘要区域改为可上下拖动的 PanedWindow，并加入扩大/缩小按钮。
- “完整摘要”与“文献详情”分离；完整摘要不做界面截断并支持滚动。
- Excel 列名改为“期刊全称/来源”，继续保存完整可获得摘要。
- 保留 v2.0.1 的 pip/HTTP 失效代理规避逻辑。
