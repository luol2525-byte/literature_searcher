﻿@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if errorlevel 1 (
    echo Python was not found. Please install Python 3.11/3.12 first.
    pause
    exit /b 1
)

rem Ignore stale proxy and pip.ini settings during dependency installation only.
set "HTTP_PROXY="
set "HTTPS_PROXY="
set "ALL_PROXY="
set "PIP_PROXY="
set "http_proxy="
set "https_proxy="
set "all_proxy="
set "pip_proxy="
set "PIP_CONFIG_FILE=NUL"

if not exist ".venv\Scripts\python.exe" (
    py -3 -m venv .venv
    if errorlevel 1 goto :error
)
call ".venv\Scripts\activate.bat"

python -m pip install --disable-pip-version-check --retries 2 --timeout 25 ^
  --index-url https://pypi.org/simple -r requirements.txt
if errorlevel 1 (
    echo [WARN] Official PyPI failed. Trying Tsinghua mirror...
    python -m pip install --disable-pip-version-check --retries 2 --timeout 25 ^
      --index-url https://pypi.tuna.tsinghua.edu.cn/simple -r requirements.txt
    if errorlevel 1 goto :error
)

python literature_searcher.py
exit /b %errorlevel%

:error
echo.
echo [ERROR] Startup/dependency installation failed.
echo Run: py -m pip config debug
pause
exit /b 1
