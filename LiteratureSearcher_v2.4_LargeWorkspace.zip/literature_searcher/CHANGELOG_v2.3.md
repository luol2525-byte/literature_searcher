# Changelog v2.3.0

- 摘要自动翻译改为免费优先多 API 回退链：MyMemory → 百度翻译 → LibreTranslate → DeepL → DeepSeek。
- 新增百度翻译 APPID/密钥设置。
- 新增 LibreTranslate 服务地址/API Key 设置。
- 新增 DeepL API Key 设置，并自动识别 Free (`:fx`) Key。
- 新增译文有效性检查，异常结果自动切换下一翻译源。
- 结果表全部可见列支持点击表头切换升序/降序。
- 年份、JIF、引用、相关度采用数值排序；空值始终置后。
- OA/PDF 使用无、OA、PDF三级排序。
- 保留 v2.2 中英文双栏摘要、同步滚动、翻译缓存、完整摘要导出以及代理修复逻辑。
