# v2.6.0

- 新增“API访问速度 / 限流”设置页。
- OpenAlex、Crossref、Semantic Scholar、Europe PMC、arXiv、WoS、SerpAPI、Unpaywall、JCR 和五个翻译 API 均可独立设置最小请求间隔（秒/次）。
- 同一 API 请求串行排队，防止多线程形成突发流量；不同 API 仍可并行。
- HTTP 429/5xx 支持 Retry-After、指数退避、随机抖动和来源级冷却。
- 去除旧版翻译/arXiv/JCR 中写死的 sleep，统一由可配置限速器管理。
- API 速度设置与其他设置一起自动持久化，下次启动恢复。
- 保留 v2.5 的 DPAPI 密钥加密、代理修复、大工作区、双栏摘要和表头排序功能。
