# -*- coding: utf-8 -*-
"""
Literature Searcher v2.8 - provider-aware randomized safe-rate profile persistent-settings large-workspace multi-source bilingual academic literature search desktop app.

Structured sources:
- OpenAlex
- Crossref
- Semantic Scholar
- Europe PMC
- arXiv
- Web of Science Starter API (API key required)
- Google Scholar via SerpAPI (optional third-party API key)

Browser-assisted sources (no bulk scraping):
- Google Scholar
- Baidu Scholar
- Bing Academic
- X-MOL advanced literature search

Features:
- AND / OR / NOT / parentheses / quoted phrase queries
- year, citation, OA/PDF, journal whitelist, impact-factor filters
- local relevance scoring and sorting
- abstract, citations, OA/PDF links
- JCR Journal Impact Factor enrichment via WoS Journals API (licensed API key)
- optional local journal impact-factor mapping file (xlsx/csv)
- Chinese/English query translation and bilingual searching
- journal full-name normalization/enrichment
- resizable bilingual full-abstract viewer with automatic multi-API translation
- free-first translation fallback chain (MyMemory/Baidu/LibreTranslate/DeepL/DeepSeek)
- click any result-column header to toggle ascending/descending sorting
- large-workspace launch layout: collapsed settings, maximized window, enlarged results/abstract panes
- persistent local settings: years, per-source limit, filters, selected sources and encrypted API credentials
- provider-aware per-API pacing: researched provider limits + randomized positive jitter + Retry-After exponential backoff
- Excel export with clickable links
"""

from __future__ import annotations

import csv
import base64
import hashlib
import html
import os
import json
import queue
import random
import re
import threading
import time
import unicodedata
import webbrowser
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from difflib import SequenceMatcher
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Callable, Iterable, Optional
from urllib.parse import quote, quote_plus
import xml.etree.ElementTree as ET

import requests
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

import tkinter as tk
from tkinter import filedialog, messagebox, ttk


APP_NAME = "Literature Searcher"
APP_VERSION = "2.8.0"
USER_AGENT = f"{APP_NAME}/{APP_VERSION} (academic literature metadata search; contact supplied by user when available)"
REQUEST_TIMEOUT = 30
MAX_RETRIES = 3
SETTINGS_SCHEMA_VERSION = 3

# Provider-aware conservative pacing profile (seconds/request).
# Values are intentionally safer/slower than the known provider ceilings.
# The actual gap for every repeated request is randomized upward by +8%..+28%
# so the client does not hammer a service at a perfectly periodic boundary.
# Provider quotas can change at any time; server Retry-After always wins.
RATE_LIMIT_DEFAULTS: dict[str, float] = {
    "openalex": 0.25,          # general API hard ceiling 100 RPS; semantic search is 1 RPS
    "crossref": 1.05,         # public list/search pool is 1 RPS; polite list/search 3 RPS
    "semantic": 1.05,         # introductory API-key rate is 1 RPS
    "europepmc": 0.20,        # 10 RPS and 500/min; 0.20 s => <=5 RPS before jitter
    "arxiv": 3.10,            # established arXiv guidance: >=3 s between repeated requests
    "wos": 1.05,              # WoS Starter Free Trial: 1 RPS (institutional plans can be higher)
    "google_serpapi": 2.00,   # hourly throughput is plan-dependent; spread requests conservatively
    "unpaywall": 0.95,        # 100,000/day => average floor about 0.864 s/request
    "jcr": 0.25,              # WoS Journals API max 5 RPS => 0.20 s theoretical floor
    "mymemory": 1.20,         # no stable published RPS found; intentionally gentle public-use default
    "baidu_translate": 1.05,  # Baidu standard text translation: 1 QPS
    "libre_translate": 1.20,  # varies by public/self-hosted instance; intentionally conservative
    "deepl": 1.00,            # account/quota dependent; rely on 429/Retry-After and avoid bursts
    "deepseek": 0.60,         # concurrency-limited rather than fixed RPS; translation is non-urgent
}
RATE_LIMIT_JITTER_MIN_RATIO = 0.08
RATE_LIMIT_JITTER_MAX_RATIO = 0.28
RATE_LIMIT_PROFILE_NAME = "内置安全限速 v2（随机抖动）"
RATE_LIMIT_BASIS: dict[str, str] = {
    "openalex": "官方：普通 API 最多 100 RPS；语义检索 1 RPS",
    "crossref": "官方：公共列表/搜索 1 RPS；Polite 列表/搜索 3 RPS",
    "semantic": "官方：API Key 初始 1 RPS；匿名池共享且可进一步节流",
    "europepmc": "服务团队：10 RPS 且 500 次/分钟（按 IP）",
    "arxiv": "官方长期使用规范：连续调用至少约 3 秒间隔",
    "wos": "官方 Starter Free Trial：1 RPS；机构方案最高 5 RPS",
    "google_serpapi": "官方：按套餐限制每小时吞吐，无统一固定 RPS",
    "unpaywall": "官方：最多 100,000 次/日",
    "jcr": "官方 WoS Journals API：最多 5 RPS",
    "mymemory": "未找到稳定公开 RPS；采用公共接口保守值",
    "baidu_translate": "官方标准版：1 QPS",
    "libre_translate": "实例自定义/套餐相关；采用保守值",
    "deepl": "账户/配额相关；无统一固定 RPS，429 时退避",
    "deepseek": "官方主要公布并发限制；无固定 RPS，429 时退避",
}
RATE_LIMIT_LABELS: dict[str, str] = {
    "openalex": "OpenAlex",
    "crossref": "Crossref",
    "semantic": "Semantic Scholar",
    "europepmc": "Europe PMC",
    "arxiv": "arXiv",
    "wos": "Web of Science",
    "google_serpapi": "Google Scholar / SerpAPI",
    "unpaywall": "Unpaywall",
    "jcr": "WoS Journals / JCR",
    "mymemory": "MyMemory 翻译",
    "baidu_translate": "百度翻译",
    "libre_translate": "LibreTranslate",
    "deepl": "DeepL",
    "deepseek": "DeepSeek",
}
RATE_LIMIT_ORDER = tuple(RATE_LIMIT_DEFAULTS)


def settings_file_path() -> Path:
    """Return a per-user settings path that survives app/project updates."""
    if os.name == "nt":
        base = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
        folder = Path(base) / "LiteratureSearcher"
    else:
        base = os.environ.get("XDG_CONFIG_HOME") or str(Path.home() / ".config")
        folder = Path(base) / "LiteratureSearcher"
    folder.mkdir(parents=True, exist_ok=True)
    return folder / "settings.json"


def protect_local_secret(value: str) -> str:
    """Protect a secret with Windows DPAPI. Non-Windows fallback is only for dev/testing."""
    value = value or ""
    if not value:
        return ""
    if os.name != "nt":
        return "local64:" + base64.b64encode(value.encode("utf-8")).decode("ascii")
    try:
        import ctypes
        from ctypes import wintypes

        class DATA_BLOB(ctypes.Structure):
            _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]

        raw = value.encode("utf-8")
        buf = ctypes.create_string_buffer(raw)
        in_blob = DATA_BLOB(len(raw), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte)))
        out_blob = DATA_BLOB()
        crypt32 = ctypes.windll.crypt32
        kernel32 = ctypes.windll.kernel32
        ok = crypt32.CryptProtectData(
            ctypes.byref(in_blob), ctypes.c_wchar_p("LiteratureSearcher"), None, None, None, 0,
            ctypes.byref(out_blob),
        )
        if not ok:
            raise ctypes.WinError()
        try:
            encrypted = ctypes.string_at(out_blob.pbData, out_blob.cbData)
        finally:
            kernel32.LocalFree(out_blob.pbData)
        return "dpapi:" + base64.b64encode(encrypted).decode("ascii")
    except Exception:
        # Never write a plaintext API key if DPAPI protection fails on Windows.
        return ""


def unprotect_local_secret(value: str) -> str:
    if not value:
        return ""
    if value.startswith("local64:") and os.name != "nt":
        try:
            return base64.b64decode(value[8:]).decode("utf-8")
        except Exception:
            return ""
    if not value.startswith("dpapi:") or os.name != "nt":
        return ""
    try:
        import ctypes
        from ctypes import wintypes

        class DATA_BLOB(ctypes.Structure):
            _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]

        raw = base64.b64decode(value[6:])
        buf = ctypes.create_string_buffer(raw)
        in_blob = DATA_BLOB(len(raw), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte)))
        out_blob = DATA_BLOB()
        crypt32 = ctypes.windll.crypt32
        kernel32 = ctypes.windll.kernel32
        ok = crypt32.CryptUnprotectData(
            ctypes.byref(in_blob), None, None, None, None, 0,
            ctypes.byref(out_blob),
        )
        if not ok:
            return ""
        try:
            decrypted = ctypes.string_at(out_blob.pbData, out_blob.cbData)
        finally:
            kernel32.LocalFree(out_blob.pbData)
        return decrypted.decode("utf-8")
    except Exception:
        return ""


# -----------------------------
# Data model and utilities
# -----------------------------

@dataclass
class Paper:
    query: str = ""
    title: str = ""
    authors: str = ""
    journal: str = ""
    year: str = ""
    doi: str = ""
    official_url: str = ""
    pdf_url: str = ""
    oa_url: str = ""
    is_oa: bool = False
    abstract: str = ""
    abstract_zh: str = ""
    abstract_en: str = ""
    citation_count: Optional[int] = None
    impact_factor: Optional[float] = None
    relevance_score: float = 0.0
    issn: str = ""
    source: str = ""


def clean_text(value: object) -> str:
    if value is None:
        return ""
    text = html.unescape(str(value))
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def normalize_doi(doi: str) -> str:
    doi = clean_text(doi).strip().lower()
    doi = re.sub(r"^https?://(dx\.)?doi\.org/", "", doi)
    doi = re.sub(r"^doi:\s*", "", doi)
    doi = doi.rstrip(".,;)")
    return doi.strip()


def extract_doi(text: str) -> str:
    if not text:
        return ""
    m = re.search(r"10\.\d{4,9}/[-._;()/:A-Z0-9]+", text, flags=re.I)
    return normalize_doi(m.group(0)) if m else ""


def doi_url(doi: str) -> str:
    doi = normalize_doi(doi)
    return f"https://doi.org/{doi}" if doi else ""


def normalize_title(title: str) -> str:
    text = unicodedata.normalize("NFKC", clean_text(title)).lower()
    text = re.sub(r"[^\w\u4e00-\u9fff]+", "", text, flags=re.UNICODE)
    return text


def normalize_journal_name(name: str) -> str:
    text = unicodedata.normalize("NFKC", clean_text(name)).casefold()
    text = text.replace("&", "and")
    text = re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "", text)
    return text


def year_value(value: object) -> str:
    if value is None:
        return ""
    match = re.search(r"(?:18|19|20|21)\d{2}", str(value))
    return match.group(0) if match else ""


def int_or_none(value: object) -> Optional[int]:
    try:
        if value is None or value == "":
            return None
        return int(float(value))
    except Exception:
        return None


def float_or_none(value: object) -> Optional[float]:
    try:
        if value is None or value == "":
            return None
        return float(value)
    except Exception:
        return None


def join_unique(values: Iterable[str], sep: str = "; ") -> str:
    seen = set()
    out = []
    for value in values:
        v = clean_text(value)
        key = v.casefold()
        if v and key not in seen:
            seen.add(key)
            out.append(v)
    return sep.join(out)


def merge_delimited(a: str, b: str) -> str:
    vals = []
    for part in (a, b):
        vals.extend(x.strip() for x in re.split(r"[;；]", part or "") if x.strip())
    return join_unique(vals)


def choose_longer(a: str, b: str) -> str:
    return b if len(clean_text(b)) > len(clean_text(a)) else a


def paper_key(paper: Paper) -> str:
    doi = normalize_doi(paper.doi)
    if doi:
        return "doi:" + doi
    title = normalize_title(paper.title)
    if title:
        return "title:" + title
    return "url:" + clean_text(paper.official_url).lower()


def reconstruct_openalex_abstract(index: object) -> str:
    if not isinstance(index, dict) or not index:
        return ""
    positions = []
    for word, pos_list in index.items():
        if not isinstance(pos_list, list):
            continue
        for pos in pos_list:
            if isinstance(pos, int):
                positions.append((pos, word))
    positions.sort(key=lambda x: x[0])
    return clean_text(" ".join(word for _, word in positions))


def contains_chinese(text: str) -> bool:
    return bool(re.search(r"[\u3400-\u4dbf\u4e00-\u9fff]", text or ""))


def is_probable_formula_or_acronym(term: str) -> bool:
    """Avoid translating chemical formulae/acronyms such as Ni(OH)2, OER, FeNi-LDH."""
    t = clean_text(term).strip()
    if not t or contains_chinese(t):
        return False
    if " " in t:
        return False
    if re.fullmatch(r"[A-Z][A-Z0-9+\-/]{1,11}", t):
        return True
    if re.fullmatch(r"(?:[A-Z][a-z]?\d*)+(?:\([A-Za-z0-9]+\)\d*)*", t):
        return True
    if any(ch in t for ch in "αβγδΔ") and len(t) <= 20:
        return True
    return False


# -----------------------------
# Boolean query parser
# -----------------------------

@dataclass
class QNode:
    kind: str
    value: str = ""
    left: Optional["QNode"] = None
    right: Optional["QNode"] = None


_TOKEN_RE = re.compile(
    r'''\s*(?:(AND|OR|NOT)\b|(\()|(\))|("(?:\\.|[^"\\])*")|([^\s()]+))''',
    flags=re.I,
)


def tokenize_query(query: str) -> list[tuple[str, str]]:
    # Preserve chemistry/function-style parentheses inside a term, e.g. Ni(OH)2.
    # Boolean grouping parentheses normally contain spaces/operators, e.g. (OER OR HER).
    protected_query = re.sub(
        r"(?<=[\w\-])\(([^()\s]+)\)(?=[\w\-]|$)",
        lambda m: "⟦" + m.group(1) + "⟧",
        query,
    )
    raw: list[tuple[str, str]] = []
    pos = 0
    while pos < len(protected_query):
        m = _TOKEN_RE.match(protected_query, pos)
        if not m:
            pos += 1
            continue
        pos = m.end()
        op, lp, rp, quoted, bare = m.groups()
        if op:
            raw.append((op.upper(), op.upper()))
        elif lp:
            raw.append(("LP", "("))
        elif rp:
            raw.append(("RP", ")"))
        elif quoted:
            value = quoted[1:-1].replace('\\"', '"').replace("⟦", "(").replace("⟧", ")")
            raw.append(("TERM", value))
        elif bare:
            raw.append(("TERM", bare.replace("⟦", "(").replace("⟧", ")")))

    # Insert implicit AND: alpha beta -> alpha AND beta; alpha (beta) -> alpha AND (beta)
    out: list[tuple[str, str]] = []
    prev_type = None
    for token in raw:
        typ = token[0]
        if prev_type in {"TERM", "RP"} and typ in {"TERM", "LP", "NOT"}:
            out.append(("AND", "AND"))
        elif prev_type == "RP" and typ == "LP":
            out.append(("AND", "AND"))
        out.append(token)
        prev_type = typ
    return out


def parse_query(query: str) -> Optional[QNode]:
    tokens = tokenize_query(query)
    if not tokens:
        return None
    idx = 0

    def parse_or() -> QNode:
        nonlocal idx
        node = parse_and()
        while idx < len(tokens) and tokens[idx][0] == "OR":
            idx += 1
            node = QNode("OR", left=node, right=parse_and())
        return node

    def parse_and() -> QNode:
        nonlocal idx
        node = parse_not()
        while idx < len(tokens) and tokens[idx][0] == "AND":
            idx += 1
            node = QNode("AND", left=node, right=parse_not())
        return node

    def parse_not() -> QNode:
        nonlocal idx
        if idx < len(tokens) and tokens[idx][0] == "NOT":
            idx += 1
            return QNode("NOT", left=parse_not())
        return parse_atom()

    def parse_atom() -> QNode:
        nonlocal idx
        if idx >= len(tokens):
            return QNode("TERM", "")
        typ, val = tokens[idx]
        if typ == "TERM":
            idx += 1
            return QNode("TERM", val)
        if typ == "LP":
            idx += 1
            node = parse_or()
            if idx < len(tokens) and tokens[idx][0] == "RP":
                idx += 1
            return node
        idx += 1
        return QNode("TERM", val)

    try:
        return parse_or()
    except Exception:
        return None


def query_positive_terms(node: Optional[QNode], negated: bool = False) -> list[str]:
    if node is None:
        return []
    if node.kind == "TERM":
        return [] if negated else ([node.value] if node.value else [])
    if node.kind == "NOT":
        return query_positive_terms(node.left, not negated)
    return query_positive_terms(node.left, negated) + query_positive_terms(node.right, negated)


def evaluate_query(node: Optional[QNode], text: str) -> bool:
    if node is None:
        return True
    hay = unicodedata.normalize("NFKC", text or "").casefold()
    if node.kind == "TERM":
        term = unicodedata.normalize("NFKC", node.value or "").casefold().strip()
        return bool(term) and term in hay
    if node.kind == "NOT":
        return not evaluate_query(node.left, text)
    if node.kind == "AND":
        return evaluate_query(node.left, text) and evaluate_query(node.right, text)
    if node.kind == "OR":
        return evaluate_query(node.left, text) or evaluate_query(node.right, text)
    return True


def search_plain_text(query: str) -> str:
    node = parse_query(query)
    terms = query_positive_terms(node)
    if not terms:
        return re.sub(r"\b(?:AND|OR|NOT)\b|[()]", " ", query, flags=re.I).replace('"', ' ')
    return " ".join(join_unique(terms, sep=" ").split())


def node_to_wos(node: Optional[QNode]) -> str:
    if node is None:
        return ""
    if node.kind == "TERM":
        term = node.value.replace('"', '\\"')
        return f'"{term}"'
    if node.kind == "NOT":
        return f"NOT ({node_to_wos(node.left)})"
    if node.kind in {"AND", "OR"}:
        return f"({node_to_wos(node.left)} {node.kind} {node_to_wos(node.right)})"
    return ""


def render_query_node(node: Optional[QNode]) -> str:
    if node is None:
        return ""
    if node.kind == "TERM":
        value = clean_text(node.value).replace('"', '\\"')
        if not value:
            return ""
        return f'"{value}"' if re.search(r"\s", value) else value
    if node.kind == "NOT":
        return f"NOT ({render_query_node(node.left)})"
    if node.kind in {"AND", "OR"}:
        return f"({render_query_node(node.left)} {node.kind} {render_query_node(node.right)})"
    return ""


def translate_term_mymemory(term: str, cache: dict[tuple[str, str], str]) -> str:
    """Translate a natural-language Boolean leaf using MyMemory; preserve formulas/acronyms."""
    raw = clean_text(term).strip()
    if not raw or is_probable_formula_or_acronym(raw):
        return raw
    source, target = ("zh-CN", "en") if contains_chinese(raw) else ("en", "zh-CN")
    key = (raw.casefold(), target)
    if key in cache:
        return cache[key]
    try:
        data = HTTP.json(
            "https://api.mymemory.translated.net/get",
            params={"q": raw, "langpair": f"{source}|{target}"},
        )
        translated = clean_text((data.get("responseData") or {}).get("translatedText"))
        # MyMemory sometimes returns an API/help error as translated text.
        if not translated or translated.casefold().startswith("no query specified"):
            translated = raw
    except Exception:
        translated = raw
    cache[key] = translated
    return translated


def translate_boolean_query(query: str, cache: dict[tuple[str, str], str] | None = None) -> str:
    cache = cache if cache is not None else {}
    root = parse_query(query)
    if root is None:
        return query

    def clone(node: Optional[QNode]) -> Optional[QNode]:
        if node is None:
            return None
        if node.kind == "TERM":
            return QNode("TERM", translate_term_mymemory(node.value, cache))
        return QNode(node.kind, value=node.value, left=clone(node.left), right=clone(node.right))

    translated = render_query_node(clone(root)).strip()
    return translated or query


def expand_bilingual_queries(queries: list[str]) -> tuple[list[str], list[tuple[str, str]]]:
    """Return original + opposite-language query while preserving Boolean structure."""
    cache: dict[tuple[str, str], str] = {}
    expanded: list[str] = []
    pairs: list[tuple[str, str]] = []
    seen: set[str] = set()
    for q in queries:
        q = q.strip()
        if not q:
            continue
        if q.casefold() not in seen:
            expanded.append(q)
            seen.add(q.casefold())
        translated = translate_boolean_query(q, cache).strip()
        if translated and translated.casefold() != q.casefold():
            pairs.append((q, translated))
            if translated.casefold() not in seen:
                expanded.append(translated)
                seen.add(translated.casefold())
    return expanded, pairs


def detect_abstract_language(text: str) -> str:
    """Return 'zh' when Chinese dominates enough to treat the abstract as Chinese, else 'en'."""
    text = clean_text(text)
    if not text:
        return ""
    zh = len(re.findall(r"[\u3400-\u4dbf\u4e00-\u9fff]", text))
    latin = len(re.findall(r"[A-Za-z]", text))
    if zh >= 12 and zh * 2 >= max(1, latin):
        return "zh"
    return "en"


def _chunk_for_translation(text: str, max_chars: int = 430) -> list[str]:
    """Split long abstracts conservatively for public translation APIs."""
    raw = (text or "").strip()
    if not raw:
        return []
    paragraphs = re.split(r"\n\s*\n", raw)
    out: list[str] = []
    for para in paragraphs:
        para = para.strip()
        if not para:
            continue
        if len(para) <= max_chars:
            out.append(para)
            continue
        # Sentence-aware split, preserving scientific punctuation reasonably well.
        sentences = re.split(r"(?<=[。！？.!?])\s+|(?<=[。！？])", para)
        buf = ""
        for sent in sentences:
            sent = sent.strip()
            if not sent:
                continue
            candidate = (buf + " " + sent).strip() if buf else sent
            if len(candidate) <= max_chars:
                buf = candidate
                continue
            if buf:
                out.append(buf)
                buf = ""
            while len(sent) > max_chars:
                cut = sent.rfind(" ", 0, max_chars)
                if cut < max_chars // 2:
                    cut = max_chars
                out.append(sent[:cut].strip())
                sent = sent[cut:].strip()
            buf = sent
        if buf:
            out.append(buf)
    return out


def translate_abstract_mymemory(text: str, target: str) -> str:
    """Translate a full abstract in chunks using MyMemory as a key-free fallback."""
    source = "en" if target == "zh" else "zh-CN"
    target_code = "zh-CN" if target == "zh" else "en"
    translated_chunks: list[str] = []
    for chunk in _chunk_for_translation(text):
        data = HTTP.json(
            "https://api.mymemory.translated.net/get",
            params={"q": chunk, "langpair": f"{source}|{target_code}"},
        )
        translated = clean_text((data.get("responseData") or {}).get("translatedText"))
        if not translated or translated.casefold().startswith("no query specified"):
            raise RuntimeError("公共翻译接口未返回有效译文")
        translated_chunks.append(translated)
    return "\n\n".join(translated_chunks).strip()


def translate_abstract_deepseek(text: str, target: str, api_key: str, model: str = "deepseek-flash") -> str:
    """Faithful scientific abstract translation through DeepSeek's OpenAI-compatible chat endpoint."""
    if not api_key.strip():
        raise ValueError("未填写 DeepSeek API Key")
    target_name = "简体中文" if target == "zh" else "English"
    source_name = "English" if target == "zh" else "简体中文"
    system_prompt = (
        "You are a scientific-paper translator. Translate abstracts faithfully and completely. "
        "Do not summarize, omit, expand, or explain. Preserve chemical formulas, catalyst names, "
        "abbreviations, numbers, units, symbols, oxidation states, Miller indices, and spectroscopy notation. "
        "Use standard terminology used in peer-reviewed chemistry/materials/electrochemistry papers. "
        "Return only the translated abstract."
    )
    payload = {
        "model": model or "deepseek-flash",
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"Translate the following abstract from {source_name} to {target_name}:\n\n{text}"},
        ],
        "stream": False,
        "temperature": 0.1,
    }
    headers = {"Authorization": f"Bearer {api_key.strip()}", "Content-Type": "application/json"}
    data = HTTP.post_json(
        "https://api.deepseek.com/chat/completions",
        json_data=payload,
        headers=headers,
        timeout=90,
    )
    choices = data.get("choices") or []
    if not choices:
        raise RuntimeError("DeepSeek 未返回译文")
    content = clean_text(((choices[0].get("message") or {}).get("content")))
    if not content:
        raise RuntimeError("DeepSeek 返回空译文")
    return content


def _translation_looks_valid(source: str, translated: str, target: str) -> bool:
    """Reject empty/error/obviously untranslated output so the fallback chain can continue."""
    src = clean_text(source)
    out = clean_text(translated)
    if not out or len(out) < 4:
        return False
    low = out.casefold()
    if any(x in low for x in ("no query specified", "invalid api", "quota exceeded", "too many requests")):
        return False
    if normalize_title(src) == normalize_title(out):
        return False
    if target == "zh":
        zh = len(re.findall(r"[\u3400-\u4dbf\u4e00-\u9fff]", out))
        letters = len(re.findall(r"[A-Za-z]", out))
        if zh < 8 and letters > 40:
            return False
    elif target == "en":
        letters = len(re.findall(r"[A-Za-z]", out))
        if letters < 15:
            return False
    return True


def translate_abstract_baidu(text: str, target: str, appid: str, secret: str) -> str:
    """Baidu General Text Translation API. Standard tier can be used with its free monthly quota."""
    appid = appid.strip()
    secret = secret.strip()
    if not appid or not secret:
        raise ValueError("未填写百度翻译 APPID/密钥")
    source_code = "en" if target == "zh" else "zh"
    target_code = "zh" if target == "zh" else "en"
    translated_chunks: list[str] = []
    # Baidu standard tier documents a 1000-character single-request limit; stay below it.
    chunks = _chunk_for_translation(text, max_chars=850)
    for i, chunk in enumerate(chunks):
        salt = str(int(time.time() * 1000)) + str(i)
        sign_raw = f"{appid}{chunk}{salt}{secret}".encode("utf-8")
        sign = hashlib.md5(sign_raw).hexdigest()
        data = HTTP.post_json(
            "https://fanyi-api.baidu.com/api/trans/vip/translate",
            data={"q": chunk, "from": source_code, "to": target_code, "appid": appid, "salt": salt, "sign": sign},
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            timeout=45,
        )
        if data.get("error_code"):
            raise RuntimeError(f"百度翻译 {data.get('error_code')}: {data.get('error_msg', 'unknown error')}")
        parts = data.get("trans_result") or []
        translated = "\n".join(clean_text(x.get("dst")) for x in parts if isinstance(x, dict)).strip()
        if not translated:
            raise RuntimeError("百度翻译未返回有效译文")
        translated_chunks.append(translated)
    return "\n\n".join(translated_chunks).strip()


def translate_abstract_libretranslate(text: str, target: str, base_url: str, api_key: str = "") -> str:
    """LibreTranslate-compatible endpoint. Supports self-hosted or other configured instances."""
    base = (base_url or "").strip().rstrip("/")
    if not base:
        raise ValueError("未配置 LibreTranslate 地址")
    source_code = "en" if target == "zh" else "zh"
    target_code = "zh" if target == "zh" else "en"
    translated_chunks: list[str] = []
    for chunk in _chunk_for_translation(text, max_chars=1600):
        payload = {"q": chunk, "source": source_code, "target": target_code, "format": "text"}
        if api_key.strip():
            payload["api_key"] = api_key.strip()
        data = HTTP.post_json(base + "/translate", json_data=payload, timeout=60, source="libre_translate")
        translated = clean_text(data.get("translatedText"))
        if not translated:
            raise RuntimeError(clean_text(data.get("error")) or "LibreTranslate 未返回有效译文")
        translated_chunks.append(translated)
    return "\n\n".join(translated_chunks).strip()


def translate_abstract_deepl(text: str, target: str, api_key: str) -> str:
    """DeepL API Free/Pro translation without requiring the deepl Python SDK."""
    key = api_key.strip()
    if not key:
        raise ValueError("未填写 DeepL API Key")
    host = "https://api-free.deepl.com" if key.endswith(":fx") else "https://api.deepl.com"
    payload = {
        "text": [text],
        "source_lang": "EN" if target == "zh" else "ZH",
        "target_lang": "ZH" if target == "zh" else "EN",
        "preserve_formatting": True,
    }
    data = HTTP.post_json(
        host + "/v2/translate",
        json_data=payload,
        headers={"Authorization": f"DeepL-Auth-Key {key}", "Content-Type": "application/json"},
        timeout=90,
    )
    items = data.get("translations") or []
    if not items:
        raise RuntimeError("DeepL 未返回译文")
    translated = clean_text((items[0] or {}).get("text"))
    if not translated:
        raise RuntimeError("DeepL 返回空译文")
    return translated


def translate_abstract_auto(
    text: str,
    target: str,
    *,
    baidu_appid: str = "",
    baidu_secret: str = "",
    libre_url: str = "",
    libre_key: str = "",
    deepl_key: str = "",
    deepseek_key: str = "",
    model: str = "deepseek-flash",
) -> tuple[str, str]:
    """Free-first translation chain; return (translation, provider label)."""
    errors: list[str] = []

    # 1) Key-free public API first, as requested.
    try:
        translated = translate_abstract_mymemory(text, target)
        if _translation_looks_valid(text, translated, target):
            return translated, "MyMemory（免Key）"
        errors.append("MyMemory: 译文质量检查未通过")
    except Exception as exc:
        errors.append(f"MyMemory: {exc}")

    # 2) Baidu standard tier has a free monthly quota after activation.
    if baidu_appid.strip() and baidu_secret.strip():
        try:
            translated = translate_abstract_baidu(text, target, baidu_appid, baidu_secret)
            if _translation_looks_valid(text, translated, target):
                return translated, "百度翻译"
            errors.append("百度翻译: 译文质量检查未通过")
        except Exception as exc:
            errors.append(f"百度翻译: {exc}")

    # 3) LibreTranslate is free/open-source; the configured hosted instance may require a key.
    if libre_url.strip():
        try:
            translated = translate_abstract_libretranslate(text, target, libre_url, libre_key)
            if _translation_looks_valid(text, translated, target):
                return translated, "LibreTranslate"
            errors.append("LibreTranslate: 译文质量检查未通过")
        except Exception as exc:
            errors.append(f"LibreTranslate: {exc}")

    # 4) DeepL Free when a free API key is supplied.
    if deepl_key.strip():
        try:
            translated = translate_abstract_deepl(text, target, deepl_key)
            if _translation_looks_valid(text, translated, target):
                return translated, "DeepL"
            errors.append("DeepL: 译文质量检查未通过")
        except Exception as exc:
            errors.append(f"DeepL: {exc}")

    # 5) LLM fallback last, so paid tokens are not used when a free translator succeeds.
    if deepseek_key.strip():
        try:
            translated = translate_abstract_deepseek(text, target, deepseek_key, model)
            if _translation_looks_valid(text, translated, target):
                return translated, "DeepSeek"
            errors.append("DeepSeek: 译文质量检查未通过")
        except Exception as exc:
            errors.append(f"DeepSeek: {exc}")

    raise RuntimeError("；".join(errors) if errors else "摘要翻译失败")


def local_relevance(paper: Paper, query: str) -> float:
    node = parse_query(query)
    terms = query_positive_terms(node)
    if not terms:
        terms = [search_plain_text(query)] if search_plain_text(query) else []
    title = (paper.title or "").casefold()
    abstract = (paper.abstract or "").casefold()
    journal = (paper.journal or "").casefold()
    authors = (paper.authors or "").casefold()
    score = 0.0
    for term in terms:
        t = term.casefold().strip()
        if not t:
            continue
        if t in title:
            score += 10.0
        if t in abstract:
            score += 3.0
        if t in journal:
            score += 1.5
        if t in authors:
            score += 0.5
    if evaluate_query(node, " ".join([paper.title, paper.abstract, paper.journal, paper.authors])):
        score += 8.0
    return round(score, 2)


# -----------------------------
# HTTP client
# -----------------------------

class HttpClient:
    def __init__(self):
        self.local = threading.local()
        self._config_lock = threading.Lock()
        self._rate_limits = dict(RATE_LIMIT_DEFAULTS)
        self._source_locks: dict[str, threading.Lock] = {}
        self._inflight_locks: dict[str, threading.Lock] = {}
        self._last_request_started: dict[str, float] = {}
        self._cooldown_until: dict[str, float] = {}

    def set_rate_limits(self, mapping: dict[str, float] | None) -> None:
        """Replace per-source minimum request intervals (seconds/request)."""
        if not mapping:
            return
        cleaned: dict[str, float] = {}
        for key, default in RATE_LIMIT_DEFAULTS.items():
            try:
                value = float(mapping.get(key, default))
            except Exception:
                value = default
            cleaned[key] = min(60.0, max(0.0, value))
        with self._config_lock:
            self._rate_limits.update(cleaned)

    def get_rate_limits(self) -> dict[str, float]:
        with self._config_lock:
            return dict(self._rate_limits)

    def _session(self) -> requests.Session:
        if not hasattr(self.local, "session"):
            s = requests.Session()
            # Do not inherit stale HTTP_PROXY/HTTPS_PROXY/PIP proxy settings by default.
            # Set LITERATURE_SEARCHER_USE_SYSTEM_PROXY=1 before launching if your network
            # genuinely requires a system-configured proxy.
            s.trust_env = os.environ.get("LITERATURE_SEARCHER_USE_SYSTEM_PROXY", "0").strip().lower() in {
                "1", "true", "yes", "on"
            }
            s.headers.update({
                "User-Agent": USER_AGENT,
                "Accept": "application/json, application/xml, text/xml;q=0.9, */*;q=0.8",
            })
            self.local.session = s
        return self.local.session

    def _classify_source(self, url: str) -> str:
        low = (url or "").lower()
        if "api.openalex.org" in low:
            return "openalex"
        if "api.crossref.org" in low:
            return "crossref"
        if "api.semanticscholar.org" in low:
            return "semantic"
        if "europepmc" in low and "ebi.ac.uk" in low:
            return "europepmc"
        if "export.arxiv.org" in low:
            return "arxiv"
        if "api.clarivate.com/apis/wos-starter" in low:
            return "wos"
        if "api.clarivate.com/apis/wos-journals" in low:
            return "jcr"
        if "serpapi.com" in low:
            return "google_serpapi"
        if "api.unpaywall.org" in low:
            return "unpaywall"
        if "api.mymemory.translated.net" in low:
            return "mymemory"
        if "fanyi-api.baidu.com" in low:
            return "baidu_translate"
        if "deepl.com" in low:
            return "deepl"
        if "api.deepseek.com" in low:
            return "deepseek"
        return ""

    def _source_lock(self, source: str) -> threading.Lock:
        with self._config_lock:
            lock = self._source_locks.get(source)
            if lock is None:
                lock = threading.Lock()
                self._source_locks[source] = lock
            return lock

    def _inflight_lock(self, source: str) -> threading.Lock:
        if not source:
            # Unknown/custom endpoints are not serialized globally.
            return threading.Lock()
        with self._config_lock:
            lock = self._inflight_locks.get(source)
            if lock is None:
                lock = threading.Lock()
                self._inflight_locks[source] = lock
            return lock

    def _set_cooldown(self, source: str, delay: float) -> None:
        if not source or delay <= 0:
            return
        until = time.monotonic() + delay
        with self._config_lock:
            self._cooldown_until[source] = max(self._cooldown_until.get(source, 0.0), until)

    def _wait_for_slot(self, source: str) -> None:
        if not source:
            return
        with self._config_lock:
            interval = float(self._rate_limits.get(source, 0.0) or 0.0)
        # One pacing lock per provider prevents concurrent worker threads from bursting the same API.
        # Different APIs remain independent and can run in parallel.
        lock = self._source_lock(source)
        with lock:
            now = time.monotonic()
            with self._config_lock:
                cooldown_until = self._cooldown_until.get(source, 0.0)
            cooldown_delay = max(0.0, cooldown_until - now)
            last = self._last_request_started.get(source, 0.0)
            if interval > 0 and last > 0:
                # Always add positive random jitter to the provider-specific safe base interval.
                # This makes repeated requests non-periodic while never going faster than the base.
                jitter = interval * random.uniform(RATE_LIMIT_JITTER_MIN_RATIO, RATE_LIMIT_JITTER_MAX_RATIO)
                target_gap = interval + jitter
                interval_delay = max(0.0, target_gap - (now - last))
            else:
                interval_delay = 0.0
            delay = max(cooldown_delay, interval_delay)
            if delay > 0:
                time.sleep(delay)
            self._last_request_started[source] = time.monotonic()

    def _retry_delay(self, response: requests.Response | None, attempt: int) -> float:
        if response is not None:
            value = response.headers.get("Retry-After")
            if value:
                try:
                    return min(300.0, max(0.0, float(value)))
                except ValueError:
                    # Retry-After may also be an HTTP date.
                    try:
                        when = parsedate_to_datetime(value)
                        if when.tzinfo is None:
                            when = when.replace(tzinfo=timezone.utc)
                        seconds = (when - datetime.now(timezone.utc)).total_seconds()
                        return min(300.0, max(0.0, seconds))
                    except Exception:
                        pass
        # Exponential backoff with jitter. attempt starts at zero.
        return min(60.0, (1.6 * (2 ** attempt)) + random.uniform(0.15, 0.85))

    def get(self, url: str, *, params=None, headers=None, timeout=REQUEST_TIMEOUT, source: str | None = None) -> requests.Response:
        last_error: Exception | None = None
        source_key = source or self._classify_source(url)
        for attempt in range(MAX_RETRIES):
            response: requests.Response | None = None
            try:
                with self._inflight_lock(source_key):
                    self._wait_for_slot(source_key)
                    response = self._session().get(url, params=params, headers=headers, timeout=timeout)
                if response.status_code == 429 or 500 <= response.status_code < 600:
                    if attempt < MAX_RETRIES - 1:
                        delay = self._retry_delay(response, attempt)
                        self._set_cooldown(source_key, delay)
                        time.sleep(delay)
                        continue
                response.raise_for_status()
                return response
            except requests.RequestException as exc:
                last_error = exc
                if attempt < MAX_RETRIES - 1:
                    delay = self._retry_delay(response, attempt)
                    self._set_cooldown(source_key, delay)
                    time.sleep(delay)
        if last_error:
            raise last_error
        raise RuntimeError("HTTP request failed")

    def json(self, url: str, *, params=None, headers=None, source: str | None = None) -> dict:
        return self.get(url, params=params, headers=headers, source=source).json()

    def post(self, url: str, *, json_data=None, data=None, headers=None, timeout=REQUEST_TIMEOUT, source: str | None = None) -> requests.Response:
        last_error: Exception | None = None
        source_key = source or self._classify_source(url)
        for attempt in range(MAX_RETRIES):
            response: requests.Response | None = None
            try:
                with self._inflight_lock(source_key):
                    self._wait_for_slot(source_key)
                    response = self._session().post(url, json=json_data, data=data, headers=headers, timeout=timeout)
                if response.status_code == 429 or 500 <= response.status_code < 600:
                    if attempt < MAX_RETRIES - 1:
                        delay = self._retry_delay(response, attempt)
                        self._set_cooldown(source_key, delay)
                        time.sleep(delay)
                        continue
                response.raise_for_status()
                return response
            except requests.RequestException as exc:
                last_error = exc
                if attempt < MAX_RETRIES - 1:
                    delay = self._retry_delay(response, attempt)
                    self._set_cooldown(source_key, delay)
                    time.sleep(delay)
        if last_error:
            raise last_error
        raise RuntimeError("HTTP POST request failed")

    def post_json(self, url: str, *, json_data=None, data=None, headers=None, timeout=REQUEST_TIMEOUT, source: str | None = None) -> dict:
        return self.post(
            url, json_data=json_data, data=data, headers=headers, timeout=timeout, source=source
        ).json()


HTTP = HttpClient()


def _date_filter(start_year: str, end_year: str) -> tuple[str, str]:
    start = f"{start_year}-01-01" if start_year else ""
    end = f"{end_year}-12-31" if end_year else ""
    return start, end


# -----------------------------
# Structured search sources
# -----------------------------

def search_openalex(query: str, limit: int, start_year: str, end_year: str, api_key: str = "") -> list[Paper]:
    papers: list[Paper] = []
    cursor = "*"
    start, end = _date_filter(start_year, end_year)
    filters = []
    if start:
        filters.append(f"from_publication_date:{start}")
    if end:
        filters.append(f"to_publication_date:{end}")

    while len(papers) < limit:
        params = {
            "search": query,
            "per_page": min(100, limit - len(papers)),
            "cursor": cursor,
            "sort": "relevance_score:desc",
            "select": "id,doi,display_name,publication_year,authorships,primary_location,best_oa_location,open_access,abstract_inverted_index,cited_by_count,ids",
        }
        if filters:
            params["filter"] = ",".join(filters)
        if api_key:
            params["api_key"] = api_key.strip()
        data = HTTP.json("https://api.openalex.org/works", params=params)
        rows = data.get("results", []) or []
        for item in rows:
            authors = [(a.get("author") or {}).get("display_name", "") for a in (item.get("authorships") or [])]
            primary = item.get("primary_location") or {}
            source_obj = primary.get("source") or {}
            best = item.get("best_oa_location") or {}
            oa = item.get("open_access") or {}
            doi = normalize_doi(item.get("doi", "") or "")
            official = doi_url(doi) or clean_text(primary.get("landing_page_url")) or clean_text(item.get("id"))
            pdf = clean_text(best.get("pdf_url"))
            oa_url = clean_text(best.get("landing_page_url")) or pdf
            ids = item.get("ids") or {}
            papers.append(Paper(
                query=query,
                title=clean_text(item.get("display_name")),
                authors=join_unique(authors),
                journal=clean_text(source_obj.get("display_name")),
                year=year_value(item.get("publication_year")),
                doi=doi,
                official_url=official,
                pdf_url=pdf,
                oa_url=oa_url,
                is_oa=bool(oa.get("is_oa") or pdf or oa_url),
                abstract=reconstruct_openalex_abstract(item.get("abstract_inverted_index")),
                citation_count=int_or_none(item.get("cited_by_count")),
                issn=clean_text((source_obj.get("issn") or [""])[0] if isinstance(source_obj.get("issn"), list) else source_obj.get("issn")),
                source="OpenAlex",
            ))
            if len(papers) >= limit:
                break
        if not rows:
            break
        next_cursor = (data.get("meta") or {}).get("next_cursor")
        if not next_cursor or next_cursor == cursor:
            break
        cursor = next_cursor
    return papers


def search_crossref(query: str, limit: int, start_year: str, end_year: str, email: str = "") -> list[Paper]:
    papers: list[Paper] = []
    cursor = "*"
    start, end = _date_filter(start_year, end_year)
    filters = []
    if start:
        filters.append(f"from-pub-date:{start}")
    if end:
        filters.append(f"until-pub-date:{end}")
    q = search_plain_text(query)

    while len(papers) < limit:
        rows = min(100, limit - len(papers))
        params = {"query.bibliographic": q, "rows": rows, "cursor": cursor}
        if filters:
            params["filter"] = ",".join(filters)
        if email.strip():
            params["mailto"] = email.strip()
        data = HTTP.json("https://api.crossref.org/works", params=params)
        message = data.get("message", {}) or {}
        items = message.get("items", []) or []
        for item in items:
            author_names = []
            for author in item.get("author", []) or []:
                name = " ".join(x for x in [author.get("given", ""), author.get("family", "")] if x).strip()
                if name:
                    author_names.append(name)
            title = (item.get("title") or [""])[0]
            journal = (item.get("container-title") or [""])[0]
            doi = normalize_doi(item.get("DOI", "") or "")
            year = ""
            for date_field in ("published", "published-print", "published-online", "created"):
                parts = ((item.get(date_field) or {}).get("date-parts") or [])
                if parts and parts[0]:
                    year = year_value(parts[0][0])
                    if year:
                        break
            links = item.get("link") or []
            pdf = ""
            for link in links:
                content_type = clean_text(link.get("content-type")).lower()
                url = clean_text(link.get("URL"))
                if "pdf" in content_type and url:
                    pdf = url
                    break
            issn_list = item.get("ISSN") or []
            papers.append(Paper(
                query=query,
                title=clean_text(title),
                authors=join_unique(author_names),
                journal=clean_text(journal),
                year=year,
                doi=doi,
                official_url=doi_url(doi) or clean_text(item.get("URL")),
                pdf_url=pdf,
                oa_url=pdf,
                is_oa=bool(pdf),
                abstract=clean_text(item.get("abstract")),
                citation_count=int_or_none(item.get("is-referenced-by-count")),
                issn=clean_text(issn_list[0] if issn_list else ""),
                source="Crossref",
            ))
            if len(papers) >= limit:
                break
        if not items:
            break
        next_cursor = message.get("next-cursor")
        if not next_cursor or next_cursor == cursor:
            break
        cursor = next_cursor
    return papers


def search_semantic_scholar(query: str, limit: int, start_year: str, end_year: str, api_key: str = "") -> list[Paper]:
    papers: list[Paper] = []
    offset = 0
    headers = {"x-api-key": api_key.strip()} if api_key.strip() else None
    plain = search_plain_text(query).replace("-", " ")
    date_filter = ""
    if start_year or end_year:
        start = f"{start_year}-01-01" if start_year else ""
        end = f"{end_year}-12-31" if end_year else ""
        date_filter = f"{start}:{end}"

    while len(papers) < limit and offset < 1000:
        batch = min(100, limit - len(papers), 1000 - offset)
        params = {
            "query": plain,
            "offset": offset,
            "limit": batch,
            "fields": "title,authors,year,venue,journal,url,externalIds,abstract,citationCount,openAccessPdf",
        }
        if date_filter:
            params["publicationDateOrYear"] = date_filter
        data = HTTP.json("https://api.semanticscholar.org/graph/v1/paper/search", params=params, headers=headers)
        items = data.get("data", []) or []
        for item in items:
            authors = [a.get("name", "") for a in item.get("authors", []) or []]
            ext = item.get("externalIds") or {}
            doi = normalize_doi(ext.get("DOI", "") or "")
            journal_obj = item.get("journal") or {}
            journal = clean_text(journal_obj.get("name")) or clean_text(item.get("venue"))
            oa_pdf = item.get("openAccessPdf") or {}
            pdf = clean_text(oa_pdf.get("url"))
            papers.append(Paper(
                query=query,
                title=clean_text(item.get("title")),
                authors=join_unique(authors),
                journal=journal,
                year=year_value(item.get("year")),
                doi=doi,
                official_url=doi_url(doi) or clean_text(item.get("url")),
                pdf_url=pdf,
                oa_url=pdf,
                is_oa=bool(pdf),
                abstract=clean_text(item.get("abstract")),
                citation_count=int_or_none(item.get("citationCount")),
                source="Semantic Scholar",
            ))
            if len(papers) >= limit:
                break
        if len(items) < batch:
            break
        offset += len(items)
    return papers


def search_europe_pmc(query: str, limit: int, start_year: str, end_year: str) -> list[Paper]:
    papers: list[Paper] = []
    page = 1
    query_text = query
    if start_year or end_year:
        sy = start_year or "1000"
        ey = end_year or "3000"
        query_text = f"({query}) AND FIRST_PDATE:[{sy}-01-01 TO {ey}-12-31]"

    while len(papers) < limit:
        batch = min(1000, limit - len(papers))
        params = {"query": query_text, "format": "json", "resultType": "core", "pageSize": batch, "page": page}
        data = HTTP.json("https://www.ebi.ac.uk/europepmc/webservices/rest/search", params=params)
        result_list = (data.get("resultList") or {}).get("result", []) or []
        for item in result_list:
            doi = normalize_doi(item.get("doi", "") or "")
            authors = []
            for a in ((item.get("authorList") or {}).get("author") or []):
                name = a.get("fullName") or a.get("collectiveName") or ""
                if name:
                    authors.append(name)
            if not authors and item.get("authorString"):
                authors = [item.get("authorString")]
            journal = clean_text(item.get("journalTitle"))
            if not journal:
                journal = clean_text(((item.get("journalInfo") or {}).get("journal") or {}).get("title"))
            src = clean_text(item.get("source"))
            ext_id = clean_text(item.get("id"))
            epmc_link = f"https://europepmc.org/article/{quote(src)}/{quote(ext_id)}" if src and ext_id else ""
            pdf = ""
            full_text_urls = ((item.get("fullTextUrlList") or {}).get("fullTextUrl") or [])
            for u in full_text_urls:
                url = clean_text(u.get("url"))
                style = clean_text(u.get("documentStyle")).lower()
                if url and ("pdf" in style or url.lower().endswith(".pdf")):
                    pdf = url
                    break
            is_oa = str(item.get("isOpenAccess", "")).upper() == "Y" or bool(pdf)
            papers.append(Paper(
                query=query,
                title=clean_text(item.get("title")),
                authors=join_unique(authors),
                journal=journal,
                year=year_value(item.get("pubYear") or item.get("firstPublicationDate")),
                doi=doi,
                official_url=doi_url(doi) or epmc_link,
                pdf_url=pdf,
                oa_url=epmc_link if is_oa else pdf,
                is_oa=is_oa,
                abstract=clean_text(item.get("abstractText")),
                citation_count=int_or_none(item.get("citedByCount")),
                issn=clean_text(item.get("journalIssn")),
                source="Europe PMC",
            ))
            if len(papers) >= limit:
                break
        if len(result_list) < batch:
            break
        page += 1
    return papers


def search_arxiv(query: str, limit: int, start_year: str, end_year: str) -> list[Paper]:
    papers: list[Paper] = []
    start_index = 0
    ns = {"atom": "http://www.w3.org/2005/Atom", "arxiv": "http://arxiv.org/schemas/atom"}
    terms = query_positive_terms(parse_query(query)) or [search_plain_text(query)]
    arxiv_query = " AND ".join(f'all:"{t.replace(chr(34), "")}"' for t in terms if t)
    if not arxiv_query:
        arxiv_query = f'all:"{search_plain_text(query)}"'

    while len(papers) < limit:
        batch = min(100, limit - len(papers))
        params = {
            "search_query": arxiv_query,
            "start": start_index,
            "max_results": batch,
            "sortBy": "relevance",
            "sortOrder": "descending",
        }
        text = HTTP.get("https://export.arxiv.org/api/query", params=params).text
        root = ET.fromstring(text)
        entries = root.findall("atom:entry", ns)
        for entry in entries:
            published = clean_text(entry.findtext("atom:published", default="", namespaces=ns))
            y = year_value(published)
            if start_year and y and int(y) < int(start_year):
                continue
            if end_year and y and int(y) > int(end_year):
                continue
            authors = [clean_text(a.findtext("atom:name", default="", namespaces=ns)) for a in entry.findall("atom:author", ns)]
            title = clean_text(entry.findtext("atom:title", default="", namespaces=ns))
            summary = clean_text(entry.findtext("atom:summary", default="", namespaces=ns))
            entry_id = clean_text(entry.findtext("atom:id", default="", namespaces=ns))
            doi_node = entry.find("arxiv:doi", ns)
            doi = normalize_doi(doi_node.text if doi_node is not None and doi_node.text else "")
            pdf = ""
            for link in entry.findall("atom:link", ns):
                if link.attrib.get("type") == "application/pdf" or link.attrib.get("title") == "pdf":
                    pdf = clean_text(link.attrib.get("href"))
                    break
            papers.append(Paper(
                query=query,
                title=title,
                authors=join_unique(authors),
                journal="arXiv",
                year=y,
                doi=doi,
                official_url=doi_url(doi) or entry_id,
                pdf_url=pdf,
                oa_url=pdf or entry_id,
                is_oa=True,
                abstract=summary,
                source="arXiv",
            ))
            if len(papers) >= limit:
                break
        if len(entries) < batch:
            break
        start_index += len(entries)
    return papers


def search_wos(query: str, limit: int, start_year: str, end_year: str, api_key: str, sort_mode: str = "relevance") -> list[Paper]:
    if not api_key.strip():
        raise RuntimeError("Web of Science Starter API Key 未填写")
    papers: list[Paper] = []
    node = parse_query(query)
    topic = node_to_wos(node) or f'"{search_plain_text(query)}"'
    q = f"TS=({topic})"
    headers = {"X-ApiKey": api_key.strip()}
    page = 1
    sort_map = {"relevance": "RS+D", "year": "PY+D", "citations": "TC+D"}
    params_base = {"db": "WOS", "q": q, "sortField": sort_map.get(sort_mode, "RS+D")}
    if start_year or end_year:
        sy = start_year or "1900"
        ey = end_year or str(datetime.now().year)
        params_base["publishTimeSpan"] = f"{sy}-01-01+{ey}-12-31"

    while len(papers) < limit:
        batch = min(50, limit - len(papers))
        params = dict(params_base)
        params.update({"limit": batch, "page": page})
        data = HTTP.json("https://api.clarivate.com/apis/wos-starter/v1/documents", params=params, headers=headers)
        hits = data.get("hits", []) or []
        for item in hits:
            names = item.get("names") or {}
            authors = [a.get("displayName", "") for a in names.get("authors", []) or []]
            source_obj = item.get("source") or {}
            ids = item.get("identifiers") or {}
            doi = normalize_doi(ids.get("doi", "") or "")
            links = item.get("links") or {}
            citations = item.get("citations") or []
            ccount = None
            if citations:
                counts = [int_or_none(c.get("count")) for c in citations]
                counts = [x for x in counts if x is not None]
                ccount = max(counts) if counts else None
            papers.append(Paper(
                query=query,
                title=clean_text(item.get("title")),
                authors=join_unique(authors),
                journal=clean_text(source_obj.get("sourceTitle")),
                year=year_value(source_obj.get("publishYear")),
                doi=doi,
                official_url=doi_url(doi) or clean_text(links.get("record")),
                citation_count=ccount,
                issn=clean_text(ids.get("issn") or ids.get("eissn")),
                source="Web of Science",
            ))
            if len(papers) >= limit:
                break
        meta = data.get("metadata") or {}
        total = int_or_none(meta.get("total")) or 0
        if not hits or page * batch >= total:
            break
        page += 1
    return papers


def search_google_scholar_serpapi(query: str, limit: int, start_year: str, end_year: str, api_key: str, sort_mode: str = "relevance") -> list[Paper]:
    if not api_key.strip():
        raise RuntimeError("SerpAPI Key 未填写；可改用“浏览器检索”打开 Google Scholar")
    papers: list[Paper] = []
    start = 0
    while len(papers) < limit and start < 1000:
        batch = min(20, limit - len(papers))
        params = {
            "engine": "google_scholar",
            "q": query,
            "api_key": api_key.strip(),
            "start": start,
            "num": batch,
            "hl": "en",
        }
        if start_year:
            params["as_ylo"] = start_year
        if end_year:
            params["as_yhi"] = end_year
        if sort_mode == "year":
            params["scisbd"] = 2
        data = HTTP.json("https://serpapi.com/search.json", params=params)
        rows = data.get("organic_results", []) or []
        for item in rows:
            pub = item.get("publication_info") or {}
            summary = clean_text(pub.get("summary"))
            pieces = [p.strip() for p in summary.split(" - ") if p.strip()]
            authors = pieces[0] if pieces else ""
            journal = pieces[1] if len(pieces) >= 2 else ""
            year = year_value(summary)
            if journal and year:
                journal = re.sub(rf"[,\s]*{re.escape(year)}.*$", "", journal).strip(" ,")
            inline = item.get("inline_links") or {}
            cited = inline.get("cited_by") or {}
            resources = item.get("resources") or []
            pdf = ""
            for r in resources:
                link = clean_text(r.get("link"))
                fmt = clean_text(r.get("file_format")).lower()
                if link and ("pdf" in fmt or link.lower().endswith(".pdf")):
                    pdf = link
                    break
            title = clean_text(item.get("title"))
            link = clean_text(item.get("link"))
            snippet = clean_text(item.get("snippet"))
            doi = extract_doi(" ".join([link, snippet]))
            papers.append(Paper(
                query=query,
                title=title,
                authors=authors,
                journal=journal,
                year=year,
                doi=doi,
                official_url=doi_url(doi) or link,
                pdf_url=pdf,
                oa_url=pdf,
                is_oa=bool(pdf),
                abstract=snippet,
                citation_count=int_or_none(cited.get("total")),
                source="Google Scholar (SerpAPI)",
            ))
            if len(papers) >= limit:
                break
        if len(rows) < batch:
            break
        start += len(rows)
    return papers


SEARCH_ENGINES: dict[str, str] = {
    "openalex": "OpenAlex",
    "crossref": "Crossref",
    "semantic": "Semantic Scholar",
    "europepmc": "Europe PMC",
    "arxiv": "arXiv",
    "wos": "Web of Science",
    "google_serpapi": "Google Scholar (SerpAPI)",
}


# -----------------------------
# Enrichment and merging
# -----------------------------

COMMON_JOURNAL_FULL_NAMES = {
    "j am chem soc": "Journal of the American Chemical Society",
    "j. am. chem. soc.": "Journal of the American Chemical Society",
    "journal of the american chemical society": "Journal of the American Chemical Society",
    "angew chem int ed": "Angewandte Chemie International Edition",
    "angew. chem. int. ed.": "Angewandte Chemie International Edition",
    "angewandte chemie international edition": "Angewandte Chemie International Edition",
    "acs catal": "ACS Catalysis",
    "acs catal.": "ACS Catalysis",
    "acs catalysis": "ACS Catalysis",
    "nat catal": "Nature Catalysis",
    "nat. catal.": "Nature Catalysis",
    "nat commun": "Nature Communications",
    "nat. commun.": "Nature Communications",
    "adv mater": "Advanced Materials",
    "adv. mater.": "Advanced Materials",
    "chem soc rev": "Chemical Society Reviews",
    "chem. soc. rev.": "Chemical Society Reviews",
    "energy environ sci": "Energy & Environmental Science",
    "energy environ. sci.": "Energy & Environmental Science",
    "appl catal b environ": "Applied Catalysis B: Environmental",
    "appl. catal. b environ.": "Applied Catalysis B: Environmental",
    "j mater chem a": "Journal of Materials Chemistry A",
    "j. mater. chem. a": "Journal of Materials Chemistry A",
    "j power sources": "Journal of Power Sources",
    "j. power sources": "Journal of Power Sources",
    "electrochim acta": "Electrochimica Acta",
    "electrochim. acta": "Electrochimica Acta",
    "j electrochem soc": "Journal of The Electrochemical Society",
    "j. electrochem. soc.": "Journal of The Electrochemical Society",
    "j phys chem c": "The Journal of Physical Chemistry C",
    "j. phys. chem. c": "The Journal of Physical Chemistry C",
    "chem eng j": "Chemical Engineering Journal",
    "chem. eng. j.": "Chemical Engineering Journal",
    "nano lett": "Nano Letters",
    "nano lett.": "Nano Letters",
    "acs nano": "ACS Nano",
    "nat chem": "Nature Chemistry",
    "nat. chem.": "Nature Chemistry",
    "nat energy": "Nature Energy",
    "nat. energy": "Nature Energy",
}


def canonical_common_journal(name: str) -> str:
    raw = clean_text(name)
    if not raw:
        return ""
    key = raw.casefold().strip()
    if key in COMMON_JOURNAL_FULL_NAMES:
        return COMMON_JOURNAL_FULL_NAMES[key]
    key2 = re.sub(r"\s+", " ", re.sub(r"[.,]", "", key)).strip()
    for abbr, full in COMMON_JOURNAL_FULL_NAMES.items():
        abbr2 = re.sub(r"\s+", " ", re.sub(r"[.,]", "", abbr.casefold())).strip()
        if key2 == abbr2:
            return full
    return raw


def journal_name_quality(name: str) -> float:
    name = canonical_common_journal(name)
    if not name:
        return -1000.0
    tokens = re.findall(r"[A-Za-z]+", name)
    score = len(name) + len(tokens) * 4
    if "." in name:
        score -= 18
    short_tokens = sum(1 for t in tokens if len(t) <= 4)
    if len(tokens) >= 2 and short_tokens / max(1, len(tokens)) >= 0.75:
        score -= 22
    if name.isupper() and len(name) < 25:
        score -= 12
    return score


def choose_better_journal_name(a: str, b: str) -> str:
    ca, cb = canonical_common_journal(a), canonical_common_journal(b)
    return cb if journal_name_quality(cb) > journal_name_quality(ca) else ca


def journal_is_probably_abbreviated(name: str) -> bool:
    raw = clean_text(name)
    if not raw or raw.casefold() == "arxiv":
        return False
    canonical = canonical_common_journal(raw)
    if canonical != raw:
        return False
    tokens = re.findall(r"[A-Za-z]+", raw)
    if "." in raw:
        return True
    if len(tokens) >= 2:
        short = sum(1 for t in tokens if len(t) <= 4)
        if short / len(tokens) >= 0.75 and len(raw) < 35:
            return True
    return False


def merge_papers(papers: Iterable[Paper]) -> list[Paper]:
    merged: dict[str, Paper] = {}
    for p in papers:
        p.journal = canonical_common_journal(p.journal)
        key = paper_key(p)
        if not key or key == "url:":
            continue
        if key not in merged:
            merged[key] = Paper(**asdict(p))
            continue
        old = merged[key]
        old.query = merge_delimited(old.query, p.query)
        old.source = merge_delimited(old.source, p.source)
        old.title = old.title or p.title
        old.authors = old.authors or p.authors
        old.journal = choose_better_journal_name(old.journal, p.journal)
        old.year = old.year or p.year
        old.doi = old.doi or p.doi
        old.official_url = old.official_url or p.official_url
        old.pdf_url = old.pdf_url or p.pdf_url
        old.oa_url = old.oa_url or p.oa_url
        old.is_oa = old.is_oa or p.is_oa
        old.abstract = choose_longer(old.abstract, p.abstract)
        old.issn = old.issn or p.issn
        if p.citation_count is not None:
            old.citation_count = max(old.citation_count or 0, p.citation_count)
        if old.impact_factor is None and p.impact_factor is not None:
            old.impact_factor = p.impact_factor
        old.relevance_score = max(old.relevance_score, p.relevance_score)
    return list(merged.values())


def enrich_crossref_metadata(
    papers: list[Paper], email: str = "", cancel_event: threading.Event | None = None, openalex_key: str = ""
) -> list[str]:
    """Prefer full journal titles and fuller abstracts using Crossref DOI/ISSN metadata."""
    errors: list[str] = []
    for p in papers:
        p.journal = canonical_common_journal(p.journal)

    targets = [
        p for p in papers
        if (p.doi or p.issn)
        and (not p.journal or journal_is_probably_abbreviated(p.journal) or len(p.abstract or "") < 220)
    ]
    if not targets:
        return errors

    def fetch(p: Paper):
        if cancel_event and cancel_event.is_set():
            return p, None, None
        params = {"mailto": email.strip()} if email.strip() else None
        try:
            if p.doi:
                journal = ""
                abstract = ""
                issn = ""
                crossref_error = None
                try:
                    url = f"https://api.crossref.org/works/{quote(normalize_doi(p.doi), safe='/')}"
                    data = HTTP.json(url, params=params)
                    msg = data.get("message") or {}
                    titles = msg.get("container-title") or []
                    journal = clean_text(titles[0] if titles else "")
                    abstract = clean_text(msg.get("abstract"))
                    issns = msg.get("ISSN") or []
                    issn = clean_text(issns[0] if issns else "")
                except Exception as exc:
                    crossref_error = exc

                # OpenAlex is often able to supply an abstract when Crossref has none.
                if len(abstract) < 220:
                    try:
                        oa_params = {
                            "select": "abstract_inverted_index,primary_location",
                        }
                        if openalex_key.strip():
                            oa_params["api_key"] = openalex_key.strip()
                        oa_url = f"https://api.openalex.org/works/https://doi.org/{quote(normalize_doi(p.doi), safe='/')}"
                        oa = HTTP.json(oa_url, params=oa_params)
                        oa_abstract = reconstruct_openalex_abstract(oa.get("abstract_inverted_index"))
                        if len(oa_abstract) > len(abstract):
                            abstract = oa_abstract
                        if not journal:
                            primary = oa.get("primary_location") or {}
                            source_obj = primary.get("source") or {}
                            journal = clean_text(source_obj.get("display_name"))
                    except Exception:
                        pass

                if journal or abstract or issn:
                    return p, {"journal": journal, "abstract": abstract, "issn": issn}, None
                if crossref_error:
                    return p, None, f"Crossref/OpenAlex metadata {p.doi}: {type(crossref_error).__name__}: {crossref_error}"
                return p, None, None
            if p.issn:
                data = HTTP.json(f"https://api.crossref.org/journals/{quote(p.issn, safe='-')}" , params=params)
                msg = data.get("message") or {}
                return p, {"journal": clean_text(msg.get("title")), "abstract": "", "issn": p.issn}, None
        except Exception as exc:
            return p, None, f"Crossref metadata {p.doi or p.issn}: {type(exc).__name__}: {exc}"
        return p, None, None

    # Keep concurrency modest for the public Crossref REST API.
    with ThreadPoolExecutor(max_workers=min(4, max(1, len(targets))), thread_name_prefix="crossref-meta") as executor:
        futures = [executor.submit(fetch, p) for p in targets]
        for future in as_completed(futures):
            if cancel_event and cancel_event.is_set():
                break
            p, meta, error = future.result()
            if error:
                errors.append(error)
                continue
            if not meta:
                continue
            full_journal = canonical_common_journal(meta.get("journal", ""))
            if full_journal:
                p.journal = choose_better_journal_name(p.journal, full_journal)
            if meta.get("abstract"):
                p.abstract = choose_longer(p.abstract, meta["abstract"])
            if not p.issn and meta.get("issn"):
                p.issn = meta["issn"]
    return errors


def enrich_unpaywall(papers: list[Paper], email: str, cancel_event: threading.Event | None = None) -> None:
    if not email.strip():
        return
    for p in papers:
        if cancel_event and cancel_event.is_set():
            return
        if not p.doi or (p.pdf_url and p.oa_url):
            continue
        try:
            data = HTTP.json(f"https://api.unpaywall.org/v2/{quote(normalize_doi(p.doi), safe='/')}", params={"email": email.strip()})
            best = data.get("best_oa_location") or {}
            p.is_oa = p.is_oa or bool(data.get("is_oa"))
            p.pdf_url = p.pdf_url or clean_text(best.get("url_for_pdf"))
            p.oa_url = p.oa_url or clean_text(best.get("url")) or clean_text(best.get("url_for_landing_page")) or p.pdf_url
        except Exception:
            continue


def load_impact_factor_map(path: str) -> dict[str, float]:
    mapping: dict[str, float] = {}
    if not path:
        return mapping
    p = Path(path)
    if not p.exists():
        return mapping

    def add_pair(name: object, val: object):
        key = normalize_journal_name(clean_text(name))
        number = float_or_none(val)
        if key and number is not None:
            mapping[key] = number

    if p.suffix.lower() == ".csv":
        with p.open("r", encoding="utf-8-sig", newline="") as f:
            rows = list(csv.reader(f))
        if not rows:
            return mapping
        header = [clean_text(x).casefold() for x in rows[0]]
        jidx = next((i for i, h in enumerate(header) if any(k in h for k in ["journal", "期刊", "source"])), 0)
        iidx = next((i for i, h in enumerate(header) if any(k in h for k in ["impact", "jif", "if", "影响因子"])), 1 if len(header) > 1 else 0)
        for row in rows[1:]:
            if len(row) > max(jidx, iidx):
                add_pair(row[jidx], row[iidx])
    else:
        wb = load_workbook(p, read_only=True, data_only=True)
        ws = wb.active
        rows = list(ws.iter_rows(values_only=True))
        if rows:
            header = [clean_text(x).casefold() for x in rows[0]]
            jidx = next((i for i, h in enumerate(header) if any(k in h for k in ["journal", "期刊", "source"])), 0)
            iidx = next((i for i, h in enumerate(header) if any(k in h for k in ["impact", "jif", "if", "影响因子"])), 1 if len(header) > 1 else 0)
            for row in rows[1:]:
                if len(row) > max(jidx, iidx):
                    add_pair(row[jidx], row[iidx])
        wb.close()
    return mapping


def apply_local_if_map(papers: list[Paper], mapping: dict[str, float]) -> None:
    if not mapping:
        return
    for p in papers:
        if p.impact_factor is not None:
            continue
        key = normalize_journal_name(p.journal)
        if key in mapping:
            p.impact_factor = mapping[key]


def best_journal_match(target: str, hits: list[dict]) -> Optional[dict]:
    if not hits:
        return None
    t = normalize_journal_name(target)
    if not t:
        return hits[0]
    exact = [h for h in hits if normalize_journal_name(h.get("name", "")) == t]
    if exact:
        return exact[0]
    return max(hits, key=lambda h: SequenceMatcher(None, t, normalize_journal_name(h.get("name", ""))).ratio())


def enrich_jcr_impact_factor(
    papers: list[Paper], api_key: str, jcr_year: str, cancel_event: threading.Event | None = None
) -> list[str]:
    errors: list[str] = []
    if not api_key.strip() or not jcr_year.strip().isdigit():
        return errors
    headers = {"X-ApiKey": api_key.strip()}
    cache: dict[str, Optional[float]] = {}
    for p in papers:
        if cancel_event and cancel_event.is_set():
            break
        if p.impact_factor is not None or not p.journal:
            continue
        cache_key = normalize_journal_name(p.journal)
        if cache_key in cache:
            p.impact_factor = cache[cache_key]
            continue
        query_value = p.issn or p.journal
        try:
            params = {
                "q": query_value,
                "jcrYear": int(jcr_year),
                "jif": "gte:0",
                "limit": 10,
                "page": 1,
            }
            data = HTTP.json("https://api.clarivate.com/apis/wos-journals/v1/journals", params=params, headers=headers)
            hits = data.get("hits", []) or []
            match = best_journal_match(p.journal, hits)
            value = None
            if match:
                metrics = ((match.get("metrics") or {}).get("impactMetrics") or {})
                value = float_or_none(metrics.get("jif"))
            cache[cache_key] = value
            p.impact_factor = value
        except Exception as exc:
            cache[cache_key] = None
            errors.append(f"JCR {p.journal}: {type(exc).__name__}: {exc}")
    return errors


# -----------------------------
# Filtering/sorting
# -----------------------------

JOURNAL_ALIASES = {
    "jacs": "journal of the american chemical society",
    "angew": "angewandte chemie international edition",
    "angewandte": "angewandte chemie international edition",
    "acs catalysis": "acs catalysis",
    "nature": "nature",
    "science": "science",
}

DEFAULT_JOURNAL_PRESET = "Nature; Science; Journal of the American Chemical Society; Angewandte Chemie International Edition; ACS Catalysis"


def parse_journal_filters(text: str) -> list[tuple[str, bool]]:
    items = [x.strip() for x in re.split(r"[;；,，\n]+", text or "") if x.strip()]
    out: list[tuple[str, bool]] = []
    for item in items:
        wildcard = item.endswith("*")
        base = item[:-1].strip() if wildcard else item
        alias = JOURNAL_ALIASES.get(base.casefold(), base)
        out.append((normalize_journal_name(alias), wildcard))
    return out


def journal_matches(journal: str, filters: list[tuple[str, bool]]) -> bool:
    if not filters:
        return True
    j = normalize_journal_name(journal)
    if not j:
        return False
    for target, wildcard in filters:
        if wildcard and j.startswith(target):
            return True
        if not wildcard and j == target:
            return True
    return False


def filter_and_sort_papers(
    papers: list[Paper], *, queries: list[str], strict_boolean: bool, start_year: str, end_year: str,
    min_citations: int, oa_only: bool, pdf_only: bool, journal_filter_text: str,
    journal_only: bool, min_if: float, sort_mode: str
) -> list[Paper]:
    filters = parse_journal_filters(journal_filter_text) if journal_only else []
    out: list[Paper] = []
    query_nodes = {q: parse_query(q) for q in queries}
    for p in papers:
        if start_year and p.year and int_or_none(p.year) is not None and int(p.year) < int(start_year):
            continue
        if end_year and p.year and int_or_none(p.year) is not None and int(p.year) > int(end_year):
            continue
        if min_citations > 0 and (p.citation_count or 0) < min_citations:
            continue
        if oa_only and not (p.is_oa or p.oa_url or p.pdf_url):
            continue
        if pdf_only and not p.pdf_url:
            continue
        if filters and not journal_matches(p.journal, filters):
            continue
        if min_if > 0 and (p.impact_factor is None or p.impact_factor < min_if):
            continue

        matched_queries = [q.strip() for q in re.split(r"[;；]", p.query or "") if q.strip()]
        # Include all bilingual variants for local filtering/scoring so a Chinese query
        # can validate an English metadata record (and vice versa).
        candidate_queries = []
        seen_q = set()
        for q in matched_queries + queries:
            key = q.casefold().strip()
            if key and key not in seen_q:
                candidate_queries.append(q)
                seen_q.add(key)
        if strict_boolean:
            searchable = " ".join([p.title, p.abstract, p.journal, p.authors])
            if not any(evaluate_query(query_nodes.get(q) or parse_query(q), searchable) for q in candidate_queries):
                continue
        p.relevance_score = max((local_relevance(p, q) for q in candidate_queries), default=0.0)
        out.append(p)

    def year_num(p: Paper) -> int:
        return int(p.year) if p.year.isdigit() else 0

    if sort_mode == "year":
        out.sort(key=lambda p: (year_num(p), p.relevance_score, p.citation_count or -1), reverse=True)
    elif sort_mode == "citations":
        out.sort(key=lambda p: (p.citation_count if p.citation_count is not None else -1, year_num(p), p.relevance_score), reverse=True)
    elif sort_mode == "impact":
        out.sort(key=lambda p: (p.impact_factor if p.impact_factor is not None else -1.0, p.citation_count or -1, year_num(p)), reverse=True)
    else:
        out.sort(key=lambda p: (p.relevance_score, p.citation_count or -1, year_num(p)), reverse=True)
    return out


# -----------------------------
# Browser-assisted search
# -----------------------------

BROWSER_SOURCES = {
    "google": "Google Scholar",
    "baidu": "百度学术",
    "bing": "Bing 学术",
    "xmol": "X-MOL",
}


def _render_google_query(node: Optional[QNode]) -> str:
    if node is None:
        return ""
    if node.kind == "TERM":
        v = node.value.strip()
        return f'"{v}"' if " " in v else v
    if node.kind == "NOT":
        inner = _render_google_query(node.left)
        return f'-({inner})'
    if node.kind == "OR":
        return f'({_render_google_query(node.left)} OR {_render_google_query(node.right)})'
    if node.kind == "AND":
        return f'{_render_google_query(node.left)} {_render_google_query(node.right)}'
    return ""


def _render_baidu_query(node: Optional[QNode]) -> str:
    # Baidu Scholar documents quotes for exact phrases, parentheses for "at least one",
    # and -(...) for exclusions. We map our Boolean tree to that syntax best-effort.
    if node is None:
        return ""
    if node.kind == "TERM":
        v = node.value.strip()
        return f'"{v}"' if " " in v else v
    if node.kind == "NOT":
        return f'-({_render_baidu_query(node.left)})'
    if node.kind == "OR":
        return f'({_render_baidu_query(node.left)} {_render_baidu_query(node.right)})'
    if node.kind == "AND":
        return f'{_render_baidu_query(node.left)} {_render_baidu_query(node.right)}'
    return ""


def browser_search_url(source: str, query: str, start_year: str, end_year: str, sort_mode: str) -> str:
    node = parse_query(query)
    if source == "google":
        google_q = _render_google_query(node) or query
        url = f"https://scholar.google.com/scholar?q={quote_plus(google_q)}"
        if start_year:
            url += f"&as_ylo={quote_plus(start_year)}"
        if end_year:
            url += f"&as_yhi={quote_plus(end_year)}"
        if sort_mode == "year":
            url += "&scisbd=2"
        return url
    if source == "baidu":
        baidu_q = _render_baidu_query(node) or query
        return f"https://xueshu.baidu.com/s?wd={quote_plus(baidu_q)}"
    if source == "bing":
        return f"https://www.bing.com/academic/?q={quote_plus(query)}"
    if source == "xmol":
        return "https://www.x-mol.com/paper/search"
    return ""


# -----------------------------
# Excel export
# -----------------------------

def export_xlsx(papers: list[Paper], file_path: str, settings: dict | None = None) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "Literature"
    headers = [
        "检索式", "题目", "作者", "期刊全称/来源", "年份", "影响因子(JIF)", "引用次数", "相关度",
        "原始摘要", "中文摘要", "英文摘要", "DOI", "官网链接", "PDF链接", "Open Access链接", "数据源"
    ]
    ws.append(headers)

    header_fill = PatternFill("solid", fgColor="1F4E78")
    header_font = Font(color="FFFFFF", bold=True)
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")

    for p in papers:
        lang = detect_abstract_language(p.abstract)
        abstract_zh = p.abstract_zh or (p.abstract if lang == "zh" else "")
        abstract_en = p.abstract_en or (p.abstract if lang == "en" else "")
        ws.append([
            p.query,
            p.title,
            p.authors,
            p.journal,
            p.year,
            p.impact_factor if p.impact_factor is not None else "",
            p.citation_count if p.citation_count is not None else "",
            p.relevance_score,
            p.abstract,
            abstract_zh,
            abstract_en,
            p.doi,
            p.official_url,
            p.pdf_url,
            p.oa_url,
            p.source,
        ])
        row = ws.max_row
        for col in (13, 14, 15):
            cell = ws.cell(row=row, column=col)
            if cell.value:
                cell.hyperlink = str(cell.value)
                cell.style = "Hyperlink"

    widths = {
        1: 28, 2: 68, 3: 42, 4: 30, 5: 9, 6: 14, 7: 12, 8: 12,
        9: 85, 10: 85, 11: 85, 12: 28, 13: 48, 14: 48, 15: 48, 16: 30,
    }
    for idx, width in widths.items():
        ws.column_dimensions[get_column_letter(idx)].width = width

    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    ws.row_dimensions[1].height = 26

    info = wb.create_sheet("Info")
    info.append(["项目", "内容"])
    info.append(["导出时间", datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
    info.append(["记录数", len(papers)])
    info.append(["程序", f"{APP_NAME} {APP_VERSION}"])
    info.append(["去重逻辑", "优先 DOI；无 DOI 时按规范化题目。多数据源合并时引用次数取最大值，摘要取更完整版本。"])
    info.append(["影响因子", "JIF 仅在配置 Web of Science Journals API 或加载本地 IF 表时填充；未授权时保持空白。"])
    if settings:
        for k, v in settings.items():
            info.append([str(k), str(v)])
    info.column_dimensions["A"].width = 24
    info.column_dimensions["B"].width = 110
    for c in info[1]:
        c.font = Font(bold=True)
    for row in info.iter_rows():
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)

    wb.save(file_path)


# -----------------------------
# GUI
# -----------------------------

class LiteratureSearcherApp(tk.Tk):
    _PERSISTENT_VARS = {
        "start_year_var": "start_year",
        "end_year_var": "end_year",
        "limit_var": "limit",
        "min_citations_var": "min_citations",
        "min_if_var": "min_if",
        "sort_var": "sort",
        "strict_boolean_var": "strict_boolean",
        "oa_only_var": "oa_only",
        "pdf_only_var": "pdf_only",
        "journal_only_var": "journal_only",
        "journal_filter_var": "journal_filter",
        "unpaywall_var": "unpaywall",
        "jcr_enrich_var": "jcr_enrich",
        "bilingual_search_var": "bilingual_search",
        "full_journal_var": "full_journal",
        "abstract_auto_translate_var": "abstract_auto_translate",
        "abstract_sync_scroll_var": "abstract_sync_scroll",
        "deepseek_model_var": "deepseek_model",
        "baidu_appid_var": "baidu_appid",
        "libre_url_var": "libre_url",
        "crossref_email_var": "crossref_email",
        "jcr_year_var": "jcr_year",
        "if_file_var": "if_file",
    }
    _SECRET_VARS = {
        "openalex_key_var": "openalex_key",
        "semantic_key_var": "semantic_key",
        "wos_key_var": "wos_key",
        "jcr_key_var": "jcr_key",
        "serpapi_key_var": "serpapi_key",
        "deepseek_key_var": "deepseek_key",
        "baidu_secret_var": "baidu_secret",
        "libre_key_var": "libre_key",
        "deepl_key_var": "deepl_key",
    }

    def _load_settings_into_vars(self):
        """Restore saved settings into Tk variables before widgets are built."""
        try:
            path = settings_file_path()
            if not path.exists():
                return
            data = json.loads(path.read_text(encoding="utf-8"))
            values = data.get("values") or {}
            for attr, key in self._PERSISTENT_VARS.items():
                if key in values and hasattr(self, attr):
                    try:
                        getattr(self, attr).set(values[key])
                    except Exception:
                        pass
            secrets = data.get("secrets") or {}
            for attr, key in self._SECRET_VARS.items():
                if key in secrets and hasattr(self, attr):
                    secret = unprotect_local_secret(str(secrets.get(key) or ""))
                    if secret:
                        getattr(self, attr).set(secret)
            for key, enabled in (data.get("engine_sources") or {}).items():
                if key in self.engine_vars:
                    self.engine_vars[key].set(bool(enabled))
            for key, enabled in (data.get("browser_sources") or {}).items():
                if key in self.browser_vars:
                    self.browser_vars[key].set(bool(enabled))
            # v2.7 uses a built-in safe-rate profile. Legacy v2.6 per-API custom
            # values are intentionally ignored so startup is safe without reconfiguration.
        except Exception:
            # A damaged/old settings file must never prevent app startup.
            return

    def _settings_payload(self) -> dict:
        values = {}
        for attr, key in self._PERSISTENT_VARS.items():
            try:
                values[key] = getattr(self, attr).get()
            except Exception:
                pass
        secrets = {}
        for attr, key in self._SECRET_VARS.items():
            try:
                raw = str(getattr(self, attr).get() or "")
            except Exception:
                raw = ""
            secrets[key] = protect_local_secret(raw) if raw else ""
        return {
            "schema_version": SETTINGS_SCHEMA_VERSION,
            "app_version": APP_VERSION,
            "saved_at": datetime.now().isoformat(timespec="seconds"),
            "values": values,
            "engine_sources": {k: bool(v.get()) for k, v in self.engine_vars.items()},
            "browser_sources": {k: bool(v.get()) for k, v in self.browser_vars.items()},
            "rate_limit_profile": RATE_LIMIT_PROFILE_NAME,
            "rate_limits_snapshot": dict(RATE_LIMIT_DEFAULTS),
            "secrets": secrets,
        }

    def _save_settings(self, show_status: bool = False):
        if getattr(self, "_settings_loading", False):
            return
        try:
            path = settings_file_path()
            tmp = path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self._settings_payload(), ensure_ascii=False, indent=2), encoding="utf-8")
            os.replace(tmp, path)
            if show_status and hasattr(self, "status_var"):
                self.status_var.set(f"设置已保存：{path}")
        except Exception as exc:
            if show_status:
                messagebox.showwarning("设置保存失败", str(exc))

    def _schedule_settings_save(self, *_args):
        if getattr(self, "_settings_loading", False):
            return
        old = getattr(self, "_settings_save_job", None)
        if old:
            try:
                self.after_cancel(old)
            except Exception:
                pass
        self._settings_save_job = self.after(700, self._save_settings)

    def _install_settings_autosave(self):
        watched = []
        for attr in list(self._PERSISTENT_VARS) + list(self._SECRET_VARS):
            if hasattr(self, attr):
                watched.append(getattr(self, attr))
        watched.extend(self.engine_vars.values())
        watched.extend(self.browser_vars.values())
        for var in watched:
            try:
                var.trace_add("write", self._schedule_settings_save)
            except Exception:
                pass
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _current_rate_limits(self) -> dict[str, float]:
        """Return the built-in safe pacing profile. No user setup is required."""
        return dict(RATE_LIMIT_DEFAULTS)

    def _apply_rate_limits(self) -> None:
        HTTP.set_rate_limits(RATE_LIMIT_DEFAULTS)

    def _reset_rate_limits(self):
        # Kept for compatibility with older UI/config code. v2.7 is always built-in.
        for key, value in RATE_LIMIT_DEFAULTS.items():
            if key in self.rate_limit_vars:
                self.rate_limit_vars[key].set(value)
        self._apply_rate_limits()
        self.status_var.set(f"已启用 {RATE_LIMIT_PROFILE_NAME}（无需手动设置）")

    def _on_close(self):
        try:
            self._save_settings()
        finally:
            self.destroy()

    def _load_saved_if_file_silent(self):
        path = self.if_file_var.get().strip()
        if not path:
            return
        try:
            if Path(path).is_file():
                self.local_if_map = load_impact_factor_map(path)
        except Exception:
            self.local_if_map = {}

    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} {APP_VERSION} - 高级多源文献检索")
        self.geometry("1680x1000")
        self.minsize(1160, 760)
        self._settings_loading = True
        self._settings_save_job = None

        self.results: list[Paper] = []
        self.msg_queue: queue.Queue = queue.Queue()
        self.cancel_event = threading.Event()
        self.search_thread: threading.Thread | None = None
        self.local_if_map: dict[str, float] = {}

        self.query_var = tk.StringVar()
        self.start_year_var = tk.StringVar()
        self.end_year_var = tk.StringVar()
        self.limit_var = tk.IntVar(value=80)
        self.min_citations_var = tk.IntVar(value=0)
        self.min_if_var = tk.DoubleVar(value=0.0)
        self.sort_var = tk.StringVar(value="相关度")
        self.strict_boolean_var = tk.BooleanVar(value=True)
        self.oa_only_var = tk.BooleanVar(value=False)
        self.pdf_only_var = tk.BooleanVar(value=False)
        self.journal_only_var = tk.BooleanVar(value=False)
        self.journal_filter_var = tk.StringVar(value=DEFAULT_JOURNAL_PRESET)
        self.unpaywall_var = tk.BooleanVar(value=True)
        self.jcr_enrich_var = tk.BooleanVar(value=False)
        self.bilingual_search_var = tk.BooleanVar(value=True)
        self.full_journal_var = tk.BooleanVar(value=True)
        self.abstract_auto_translate_var = tk.BooleanVar(value=True)
        self.abstract_sync_scroll_var = tk.BooleanVar(value=True)
        self.deepseek_model_var = tk.StringVar(value="deepseek-flash")
        self.baidu_appid_var = tk.StringVar()
        self.baidu_secret_var = tk.StringVar()
        self.libre_url_var = tk.StringVar()
        self.libre_key_var = tk.StringVar()
        self.deepl_key_var = tk.StringVar()
        self.table_sort_column = ""
        self.table_sort_desc = False

        self.openalex_key_var = tk.StringVar()
        self.semantic_key_var = tk.StringVar()
        self.crossref_email_var = tk.StringVar()
        self.wos_key_var = tk.StringVar()
        self.jcr_key_var = tk.StringVar()
        self.jcr_year_var = tk.StringVar(value=str(datetime.now().year - 1))
        self.serpapi_key_var = tk.StringVar()
        self.deepseek_key_var = tk.StringVar()
        self.if_file_var = tk.StringVar()
        self.abstract_translation_cache: dict[tuple[str, str], tuple[str, str]] = {}
        self.abstract_translation_token = 0
        self._syncing_abstract_scroll = False

        self.status_var = tk.StringVar(value="就绪")
        self.progress_var = tk.DoubleVar(value=0)

        self.engine_vars = {
            "openalex": tk.BooleanVar(value=True),
            "crossref": tk.BooleanVar(value=True),
            "semantic": tk.BooleanVar(value=True),
            "europepmc": tk.BooleanVar(value=True),
            "arxiv": tk.BooleanVar(value=True),
            "wos": tk.BooleanVar(value=False),
            "google_serpapi": tk.BooleanVar(value=False),
        }
        self.browser_vars = {k: tk.BooleanVar(value=True) for k in BROWSER_SOURCES}
        self.rate_limit_vars = {
            key: tk.DoubleVar(value=value) for key, value in RATE_LIMIT_DEFAULTS.items()
        }

        self._load_settings_into_vars()
        self._apply_rate_limits()
        self._settings_loading = False
        self._build_ui()
        self._load_saved_if_file_silent()
        self._install_settings_autosave()
        self.after(80, self._maximize_and_set_workspace)
        self.after(120, self._poll_queue)

    def _build_ui(self):
        outer = ttk.Frame(self, padding=5)
        outer.pack(fill="both", expand=True)
        self.outer = outer

        # Compact launch bar: advanced settings are collapsed by default so that
        # the result grid and bilingual abstract viewer receive most screen space.
        self.quickbar = ttk.Frame(outer)
        self.quickbar.pack(fill="x", pady=(0, 4))
        ttk.Label(self.quickbar, text="检索式：").pack(side="left")
        quick_entry = ttk.Entry(self.quickbar, textvariable=self.query_var)
        quick_entry.pack(side="left", fill="x", expand=True, padx=(5, 5))
        quick_entry.bind("<Return>", lambda _e: self.start_search())
        ttk.Button(self.quickbar, text="添加", command=self.add_query, width=7).pack(side="left", padx=2)
        self.search_btn = ttk.Button(self.quickbar, text="开始检索", command=self.start_search)
        self.search_btn.pack(side="left", padx=2)
        self.stop_btn = ttk.Button(self.quickbar, text="停止", command=self.stop_search, state="disabled")
        self.stop_btn.pack(side="left", padx=2)
        self.settings_toggle_var = tk.StringVar(value="展开设置 ▼")
        ttk.Button(self.quickbar, textvariable=self.settings_toggle_var, command=self.toggle_settings, width=12)\
            .pack(side="left", padx=(5, 0))
        ttk.Button(self.quickbar, text="保存设置", command=lambda: self._save_settings(show_status=True), width=9)\
            .pack(side="left", padx=(4, 0))

        self.settings_container = ttk.Frame(outer)
        self.settings_container.pack(fill="x", pady=(0, 4))
        self.settings_visible = True

        notebook = ttk.Notebook(self.settings_container)
        notebook.pack(fill="x")
        self.settings_notebook = notebook

        search_tab = ttk.Frame(notebook, padding=6)
        api_tab = ttk.Frame(notebook, padding=6)
        rate_tab = ttk.Frame(notebook, padding=6)
        browser_tab = ttk.Frame(notebook, padding=6)
        notebook.add(search_tab, text="检索与筛选")
        notebook.add(api_tab, text="API / JIF / OA 设置")
        notebook.add(rate_tab, text="内置 API 安全限速")
        notebook.add(browser_tab, text="Google/百度/Bing/X-MOL 网页检索")

        # Search tab
        ttk.Label(search_tab, text="检索式：").grid(row=0, column=0, sticky="w")
        entry = ttk.Entry(search_tab, textvariable=self.query_var, width=62)
        entry.grid(row=0, column=1, sticky="ew", padx=(6, 6))
        entry.bind("<Return>", lambda _e: self.add_query())
        ttk.Button(search_tab, text="添加检索式", command=self.add_query).grid(row=0, column=2, padx=3)
        ttk.Button(search_tab, text="删除选中", command=self.remove_query).grid(row=0, column=3, padx=3)
        ttk.Button(search_tab, text="清空", command=self.clear_queries).grid(row=0, column=4, padx=3)
        search_tab.columnconfigure(1, weight=1)

        ttk.Label(
            search_tab,
            text='支持：AND / OR / NOT / ( ) / "精确短语"；例如：("oxygen evolution" OR OER) AND NiFe NOT battery',
        ).grid(row=1, column=0, columnspan=5, sticky="w", pady=(4, 3))

        self.query_list = tk.Listbox(search_tab, height=2, selectmode=tk.EXTENDED)
        self.query_list.grid(row=2, column=0, columnspan=5, sticky="nsew", pady=(2, 8))

        opt1 = ttk.Frame(search_tab)
        opt1.grid(row=3, column=0, columnspan=5, sticky="ew")
        ttk.Label(opt1, text="年份").pack(side="left")
        ttk.Entry(opt1, textvariable=self.start_year_var, width=7).pack(side="left", padx=(4, 2))
        ttk.Label(opt1, text="至").pack(side="left")
        ttk.Entry(opt1, textvariable=self.end_year_var, width=7).pack(side="left", padx=(2, 12))
        ttk.Label(opt1, text="每检索式/数据源最多").pack(side="left")
        ttk.Spinbox(opt1, from_=5, to=500, increment=5, textvariable=self.limit_var, width=7).pack(side="left", padx=(4, 12))
        ttk.Label(opt1, text="最低引用").pack(side="left")
        ttk.Spinbox(opt1, from_=0, to=100000, increment=1, textvariable=self.min_citations_var, width=7).pack(side="left", padx=(4, 12))
        ttk.Label(opt1, text="最低JIF").pack(side="left")
        ttk.Spinbox(opt1, from_=0, to=1000, increment=0.1, textvariable=self.min_if_var, width=7).pack(side="left", padx=(4, 12))
        ttk.Label(opt1, text="排序").pack(side="left")
        ttk.Combobox(opt1, textvariable=self.sort_var, state="readonly", width=12,
                     values=["相关度", "年份（新→旧）", "引用次数", "影响因子"]).pack(side="left", padx=(4, 10))

        opt2 = ttk.Frame(search_tab)
        opt2.grid(row=4, column=0, columnspan=5, sticky="ew", pady=(6, 0))
        ttk.Checkbutton(opt2, text="中英文互译后联合检索", variable=self.bilingual_search_var).pack(side="left")
        ttk.Checkbutton(opt2, text="严格布尔二次筛选", variable=self.strict_boolean_var).pack(side="left", padx=(10, 0))
        ttk.Checkbutton(opt2, text="仅 Open Access", variable=self.oa_only_var).pack(side="left", padx=10)
        ttk.Checkbutton(opt2, text="仅有 PDF", variable=self.pdf_only_var).pack(side="left", padx=4)
        ttk.Checkbutton(opt2, text="仅保留指定期刊", variable=self.journal_only_var).pack(side="left", padx=10)
        ttk.Entry(opt2, textvariable=self.journal_filter_var, width=48).pack(side="left", padx=(4, 5), fill="x", expand=True)
        ttk.Button(opt2, text="高影响期刊预设", command=lambda: self.journal_filter_var.set(DEFAULT_JOURNAL_PRESET)).pack(side="left")

        source_box = ttk.LabelFrame(search_tab, text="结构化检索数据源", padding=7)
        source_box.grid(row=5, column=0, columnspan=5, sticky="ew", pady=(8, 0))
        for key, label in SEARCH_ENGINES.items():
            ttk.Checkbutton(source_box, text=label, variable=self.engine_vars[key]).pack(side="left", padx=5)

        # API tab
        api_tab.columnconfigure(1, weight=1)
        api_tab.columnconfigure(3, weight=1)
        ttk.Label(api_tab, text="OpenAlex API Key").grid(row=0, column=0, sticky="w", pady=3)
        ttk.Entry(api_tab, textvariable=self.openalex_key_var, show="•").grid(row=0, column=1, sticky="ew", padx=(6, 18))
        ttk.Label(api_tab, text="Semantic Scholar API Key").grid(row=0, column=2, sticky="w", pady=3)
        ttk.Entry(api_tab, textvariable=self.semantic_key_var, show="•").grid(row=0, column=3, sticky="ew", padx=(6, 0))

        ttk.Label(api_tab, text="Crossref / Unpaywall 邮箱").grid(row=1, column=0, sticky="w", pady=3)
        ttk.Entry(api_tab, textvariable=self.crossref_email_var).grid(row=1, column=1, sticky="ew", padx=(6, 18))
        ttk.Checkbutton(api_tab, text="用 Unpaywall 补充 OA/PDF", variable=self.unpaywall_var).grid(row=1, column=2, columnspan=2, sticky="w")

        ttk.Label(api_tab, text="WoS Starter API Key").grid(row=2, column=0, sticky="w", pady=3)
        ttk.Entry(api_tab, textvariable=self.wos_key_var, show="•").grid(row=2, column=1, sticky="ew", padx=(6, 18))
        ttk.Label(api_tab, text="SerpAPI Key（Google Scholar）").grid(row=2, column=2, sticky="w", pady=3)
        ttk.Entry(api_tab, textvariable=self.serpapi_key_var, show="•").grid(row=2, column=3, sticky="ew", padx=(6, 0))

        ttk.Label(api_tab, text="WoS Journals API Key (JCR)").grid(row=3, column=0, sticky="w", pady=3)
        ttk.Entry(api_tab, textvariable=self.jcr_key_var, show="•").grid(row=3, column=1, sticky="ew", padx=(6, 18))
        jcr_frame = ttk.Frame(api_tab)
        jcr_frame.grid(row=3, column=2, columnspan=2, sticky="w")
        ttk.Checkbutton(jcr_frame, text="检索后补充官方 JIF", variable=self.jcr_enrich_var).pack(side="left")
        ttk.Label(jcr_frame, text="JCR年份").pack(side="left", padx=(10, 3))
        ttk.Entry(jcr_frame, textvariable=self.jcr_year_var, width=7).pack(side="left")

        translation_box = ttk.LabelFrame(api_tab, text="摘要翻译 API（免费优先自动回退）", padding=6)
        translation_box.grid(row=4, column=0, columnspan=4, sticky="ew", pady=(5, 5))
        translation_box.columnconfigure(1, weight=1)
        translation_box.columnconfigure(3, weight=1)
        ttk.Label(translation_box, text="优先级").grid(row=0, column=0, sticky="w", pady=2)
        ttk.Label(
            translation_box,
            text="MyMemory免Key → 百度免费额度 → LibreTranslate → DeepL Free → DeepSeek",
        ).grid(row=0, column=1, columnspan=3, sticky="w", padx=(6, 0), pady=2)
        ttk.Label(translation_box, text="百度 APPID").grid(row=1, column=0, sticky="w", pady=2)
        ttk.Entry(translation_box, textvariable=self.baidu_appid_var).grid(row=1, column=1, sticky="ew", padx=(6, 18))
        ttk.Label(translation_box, text="百度密钥").grid(row=1, column=2, sticky="w", pady=2)
        ttk.Entry(translation_box, textvariable=self.baidu_secret_var, show="•").grid(row=1, column=3, sticky="ew", padx=(6, 0))
        ttk.Label(translation_box, text="LibreTranslate 地址").grid(row=2, column=0, sticky="w", pady=2)
        ttk.Entry(translation_box, textvariable=self.libre_url_var).grid(row=2, column=1, sticky="ew", padx=(6, 18))
        ttk.Label(translation_box, text="Libre API Key").grid(row=2, column=2, sticky="w", pady=2)
        ttk.Entry(translation_box, textvariable=self.libre_key_var, show="•").grid(row=2, column=3, sticky="ew", padx=(6, 0))
        ttk.Label(translation_box, text="DeepL API Key").grid(row=3, column=0, sticky="w", pady=2)
        ttk.Entry(translation_box, textvariable=self.deepl_key_var, show="•").grid(row=3, column=1, sticky="ew", padx=(6, 18))
        ttk.Label(translation_box, text="DeepSeek API Key").grid(row=3, column=2, sticky="w", pady=2)
        ttk.Entry(translation_box, textvariable=self.deepseek_key_var, show="•").grid(row=3, column=3, sticky="ew", padx=(6, 0))
        ttk.Label(translation_box, text="DeepSeek 模型").grid(row=4, column=0, sticky="w", pady=2)
        ttk.Combobox(
            translation_box, textvariable=self.deepseek_model_var, state="readonly", width=18,
            values=["deepseek-flash", "deepseek-v4-pro"]
        ).grid(row=4, column=1, sticky="w", padx=(6, 0))
        ttk.Label(
            translation_box,
            text="LibreTranslate 官方公共实例可能要求 Key；可填写自建或其他兼容实例地址。",
        ).grid(row=4, column=2, columnspan=2, sticky="w", padx=(6, 0))

        ttk.Label(api_tab, text="本地影响因子表").grid(row=5, column=0, sticky="w", pady=3)
        ttk.Entry(api_tab, textvariable=self.if_file_var).grid(row=5, column=1, columnspan=2, sticky="ew", padx=(6, 6))
        ttk.Button(api_tab, text="加载 xlsx/csv", command=self.load_if_file).grid(row=5, column=3, sticky="w")
        ttk.Label(api_tab, text="表格至少含 Journal/期刊列 与 IF/JIF/影响因子列。JCR 官方 JIF 需要相应 Clarivate 授权。")\
            .grid(row=6, column=0, columnspan=4, sticky="w", pady=(4, 0))
        ttk.Checkbutton(
            api_tab, text="自动补全期刊全称并补充更完整摘要（Crossref DOI/ISSN 元数据）",
            variable=self.full_journal_var
        ).grid(row=7, column=0, columnspan=4, sticky="w", pady=(6, 0))
        ttk.Checkbutton(
            api_tab, text="选中文献后自动生成中英文双栏摘要（免费接口优先，多 API 自动回退）",
            variable=self.abstract_auto_translate_var
        ).grid(row=8, column=0, columnspan=4, sticky="w", pady=(4, 0))
        ttk.Label(
            api_tab,
            text="设置会自动保存到当前 Windows 用户配置目录；API Key 使用 Windows DPAPI 加密，不以明文保存。",
        ).grid(row=9, column=0, columnspan=4, sticky="w", pady=(7, 0))

        # Built-in per-API request pacing tab
        ttk.Label(
            rate_tab,
            text=f"{RATE_LIMIT_PROFILE_NAME}：按各服务公开限制设置安全基准；每次重复请求再随机增加 8%–28% 间隔。",
        ).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 4))
        ttk.Label(
            rate_tab,
            text="同一 API 串行排队、不同 API 可并行；429/5xx 优先遵守 Retry-After，并执行来源级指数退避。",
        ).grid(row=1, column=0, columnspan=4, sticky="w", pady=(0, 8))

        search_rate_box = ttk.LabelFrame(rate_tab, text="文献检索 / 元数据 API（内置）", padding=6)
        search_rate_box.grid(row=2, column=0, columnspan=2, sticky="nsew", padx=(0, 8))
        translate_rate_box = ttk.LabelFrame(rate_tab, text="摘要翻译 API（内置）", padding=6)
        translate_rate_box.grid(row=2, column=2, columnspan=2, sticky="nsew")
        for c in range(4):
            rate_tab.columnconfigure(c, weight=1)

        search_rate_keys = [
            "openalex", "crossref", "semantic", "europepmc", "arxiv", "wos",
            "google_serpapi", "unpaywall", "jcr",
        ]
        translation_rate_keys = ["mymemory", "baidu_translate", "libre_translate", "deepl", "deepseek"]

        def add_builtin_rate_rows(parent, keys):
            parent.columnconfigure(0, weight=0)
            parent.columnconfigure(1, weight=0)
            parent.columnconfigure(2, weight=1)
            for row, key in enumerate(keys):
                base = RATE_LIMIT_DEFAULTS[key]
                low = base * (1.0 + RATE_LIMIT_JITTER_MIN_RATIO)
                high = base * (1.0 + RATE_LIMIT_JITTER_MAX_RATIO)
                ttk.Label(parent, text=RATE_LIMIT_LABELS[key]).grid(row=row, column=0, sticky="w", pady=2)
                ttk.Label(
                    parent, text=f"{base:.2f}s + 随机 → {low:.2f}–{high:.2f}s", width=26, anchor="e"
                ).grid(row=row, column=1, sticky="e", padx=(10, 8), pady=2)
                ttk.Label(parent, text=RATE_LIMIT_BASIS.get(key, ""), wraplength=430, justify="left")\
                    .grid(row=row, column=2, sticky="w", pady=2)

        add_builtin_rate_rows(search_rate_box, search_rate_keys)
        add_builtin_rate_rows(translate_rate_box, translation_rate_keys)

        rate_info = ttk.Frame(rate_tab)
        rate_info.grid(row=3, column=0, columnspan=4, sticky="w", pady=(8, 0))
        ttk.Label(
            rate_info,
            text="软件启动即自动启用；旧版手动限速不会覆盖 v2.8 安全值。随机值只会增加等待时间，不会让请求快于安全基准。",
        ).pack(side="left")

        # Browser tab
        ttk.Label(browser_tab, text="这些网站默认以浏览器方式检索，不在后台批量抓取结果。勾选平台后可一次打开检索页。")\
            .grid(row=0, column=0, columnspan=5, sticky="w")
        browser_src = ttk.Frame(browser_tab)
        browser_src.grid(row=1, column=0, columnspan=5, sticky="w", pady=(8, 6))
        for key, label in BROWSER_SOURCES.items():
            ttk.Checkbutton(browser_src, text=label, variable=self.browser_vars[key]).pack(side="left", padx=7)
        ttk.Button(browser_tab, text="打开所选网站检索", command=self.open_browser_searches).grid(row=2, column=0, sticky="w")
        ttk.Label(browser_tab, text="X-MOL 当前打开其高级检索页；程序会把第一个检索式复制到剪贴板，便于直接粘贴。")\
            .grid(row=2, column=1, columnspan=4, sticky="w", padx=(12, 0))

        # Compact action toolbar
        toolbar = ttk.Frame(outer)
        self.toolbar = toolbar
        toolbar.pack(fill="x", pady=(0, 3))
        self.export_btn = ttk.Button(toolbar, text="导出 Excel", command=self.export_excel, state="disabled")
        self.export_btn.pack(side="left")
        ttk.Button(toolbar, text="打开官网", command=self.open_selected_official).pack(side="left", padx=4)
        ttk.Button(toolbar, text="打开 PDF/OA", command=self.open_selected_pdf).pack(side="left", padx=4)
        ttk.Button(toolbar, text="复制 DOI", command=self.copy_selected_doi).pack(side="left", padx=4)
        ttk.Button(toolbar, text="清空结果", command=self.clear_results).pack(side="left", padx=4)
        ttk.Label(toolbar, text="双击结果：打开官网/DOI；点击表头：升/降序").pack(side="right")

        progress_frame = ttk.Frame(outer)
        self.progress_frame = progress_frame
        progress_frame.pack(fill="x", pady=(0, 4))
        ttk.Progressbar(progress_frame, variable=self.progress_var, maximum=100).pack(side="left", fill="x", expand=True)
        ttk.Label(progress_frame, textvariable=self.status_var, width=62).pack(side="left", padx=(8, 0))

        # Results table + vertically resizable full-abstract area
        self.result_pane = ttk.Panedwindow(outer, orient="vertical")
        self.result_pane.pack(fill="both", expand=True)
        result_frame = ttk.Frame(self.result_pane)
        abstract_frame = ttk.LabelFrame(self.result_pane, text="完整摘要 / 文献详情（可拖动分隔条调整面积）", padding=4)
        self.result_pane.add(result_frame, weight=11)
        self.result_pane.add(abstract_frame, weight=9)

        columns = ("title", "journal", "year", "if", "citations", "oa", "doi", "source", "score")
        self.tree = ttk.Treeview(result_frame, columns=columns, show="headings")
        headings = {
            "title": "题目", "journal": "期刊全称/来源", "year": "年份", "if": "JIF",
            "citations": "引用", "oa": "OA/PDF", "doi": "DOI", "source": "数据源", "score": "相关度"
        }
        widths = {"title": 470, "journal": 275, "year": 64, "if": 68, "citations": 72, "oa": 70,
                  "doi": 190, "source": 190, "score": 75}
        self.tree_headings = headings
        for col in columns:
            self.tree.heading(col, text=headings[col] + " ↕", command=lambda c=col: self.sort_results_by_column(c))
            self.tree.column(col, width=widths[col], minwidth=50, anchor="w")
        for col in ("year", "if", "citations", "oa", "score"):
            self.tree.column(col, anchor="center")

        yscroll = ttk.Scrollbar(result_frame, orient="vertical", command=self.tree.yview)
        xscroll = ttk.Scrollbar(result_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        yscroll.grid(row=0, column=1, sticky="ns")
        xscroll.grid(row=1, column=0, sticky="ew")
        result_frame.rowconfigure(0, weight=1)
        result_frame.columnconfigure(0, weight=1)
        self.tree.bind("<Double-1>", self.open_selected_official)
        self.tree.bind("<<TreeviewSelect>>", self.show_selected_abstract)

        abstract_toolbar = ttk.Frame(abstract_frame)
        abstract_toolbar.pack(fill="x", pady=(0, 4))
        ttk.Label(abstract_toolbar, text="中英文摘要双栏对应显示；原文完整保留，译文后台自动生成。")\
            .pack(side="left")
        ttk.Checkbutton(abstract_toolbar, text="自动翻译", variable=self.abstract_auto_translate_var).pack(side="left", padx=(12, 4))
        ttk.Checkbutton(abstract_toolbar, text="同步滚动", variable=self.abstract_sync_scroll_var).pack(side="left", padx=4)
        self.translation_status_var = tk.StringVar(value="")
        ttk.Label(abstract_toolbar, textvariable=self.translation_status_var).pack(side="left", padx=(12, 0))
        ttk.Button(abstract_toolbar, text="重新翻译", command=self.retranslate_selected_abstract).pack(side="right", padx=3)
        ttk.Button(abstract_toolbar, text="扩大摘要", command=lambda: self._adjust_abstract_pane(-120)).pack(side="right", padx=3)
        ttk.Button(abstract_toolbar, text="缩小摘要", command=lambda: self._adjust_abstract_pane(120)).pack(side="right", padx=3)

        abstract_tabs = ttk.Notebook(abstract_frame)
        abstract_tabs.pack(fill="both", expand=True)
        abs_tab = ttk.Frame(abstract_tabs)
        detail_tab = ttk.Frame(abstract_tabs)
        abstract_tabs.add(abs_tab, text="中英文双栏摘要")
        abstract_tabs.add(detail_tab, text="文献详情")

        abs_pane = ttk.Panedwindow(abs_tab, orient="horizontal")
        abs_pane.pack(fill="both", expand=True)
        left_panel = ttk.Frame(abs_pane, padding=(0, 0, 4, 0))
        right_panel = ttk.Frame(abs_pane, padding=(4, 0, 0, 0))
        abs_pane.add(left_panel, weight=1)
        abs_pane.add(right_panel, weight=1)

        self.left_abs_title_var = tk.StringVar(value="原始摘要")
        self.right_abs_title_var = tk.StringVar(value="自动翻译")
        ttk.Label(left_panel, textvariable=self.left_abs_title_var, anchor="center").grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 4))
        ttk.Label(right_panel, textvariable=self.right_abs_title_var, anchor="center").grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 4))

        self.abstract_text = tk.Text(left_panel, height=18, wrap="word", undo=False, font=("Segoe UI", 11))
        self.abstract_translation_text = tk.Text(right_panel, height=18, wrap="word", undo=False, font=("Segoe UI", 11))
        self.abstract_scroll_left = ttk.Scrollbar(left_panel, orient="vertical", command=self._scroll_left_abstract)
        self.abstract_scroll_right = ttk.Scrollbar(right_panel, orient="vertical", command=self._scroll_right_abstract)
        self.abstract_text.configure(yscrollcommand=self._left_abstract_yset)
        self.abstract_translation_text.configure(yscrollcommand=self._right_abstract_yset)
        self.abstract_text.grid(row=1, column=0, sticky="nsew")
        self.abstract_scroll_left.grid(row=1, column=1, sticky="ns")
        self.abstract_translation_text.grid(row=1, column=0, sticky="nsew")
        self.abstract_scroll_right.grid(row=1, column=1, sticky="ns")
        for panel in (left_panel, right_panel):
            panel.rowconfigure(1, weight=1)
            panel.columnconfigure(0, weight=1)
        self.abstract_text.configure(state="disabled")
        self.abstract_translation_text.configure(state="disabled")
        self.abstract_text.bind("<MouseWheel>", self._on_abstract_mousewheel)
        self.abstract_translation_text.bind("<MouseWheel>", self._on_abstract_mousewheel)
        self.abstract_text.bind("<Button-4>", lambda e: self._on_linux_abstract_wheel(self.abstract_text, -1))
        self.abstract_text.bind("<Button-5>", lambda e: self._on_linux_abstract_wheel(self.abstract_text, 1))
        self.abstract_translation_text.bind("<Button-4>", lambda e: self._on_linux_abstract_wheel(self.abstract_translation_text, -1))
        self.abstract_translation_text.bind("<Button-5>", lambda e: self._on_linux_abstract_wheel(self.abstract_translation_text, 1))

        self.detail_text = tk.Text(detail_tab, height=16, wrap="word", undo=False, font=("Segoe UI", 11))
        detail_scroll = ttk.Scrollbar(detail_tab, orient="vertical", command=self.detail_text.yview)
        self.detail_text.configure(yscrollcommand=detail_scroll.set)
        self.detail_text.grid(row=0, column=0, sticky="nsew")
        detail_scroll.grid(row=0, column=1, sticky="ns")
        detail_tab.rowconfigure(0, weight=1)
        detail_tab.columnconfigure(0, weight=1)
        self.detail_text.configure(state="disabled")

        # Launch in large-workspace mode: hide advanced settings after widgets are built.
        self.settings_container.pack_forget()
        self.settings_visible = False
        self.settings_toggle_var.set("展开设置 ▼")

    def toggle_settings(self):
        """Show/hide the advanced settings area without stealing permanent workspace."""
        if self.settings_visible:
            self.settings_container.pack_forget()
            self.settings_visible = False
            self.settings_toggle_var.set("展开设置 ▼")
        else:
            # Insert it back above the action toolbar, preserving the large result area when closed.
            self.settings_container.pack(fill="x", pady=(0, 4), before=self.toolbar)
            self.settings_visible = True
            self.settings_toggle_var.set("收起设置 ▲")
        self.after_idle(self._set_default_pane_split)

    def _maximize_and_set_workspace(self):
        """Maximize on Windows and give results/abstracts most of the initial screen."""
        try:
            if os.name == "nt":
                self.state("zoomed")
            else:
                sw = max(self.winfo_screenwidth(), 1280)
                sh = max(self.winfo_screenheight(), 800)
                self.geometry(f"{int(sw * 0.94)}x{int(sh * 0.90)}+20+20")
        except Exception:
            pass
        self.after(120, self._set_default_pane_split)

    def _set_default_pane_split(self):
        try:
            self.update_idletasks()
            total = self.result_pane.winfo_height()
            if total > 360:
                # Slightly more than half for the result grid, with a large abstract pane below.
                self.result_pane.sashpos(0, int(total * 0.54))
        except Exception:
            pass

    def add_query(self):
        text = self.query_var.get().strip()
        if not text:
            return
        existing = {self.query_list.get(i).casefold() for i in range(self.query_list.size())}
        if text.casefold() not in existing:
            self.query_list.insert(tk.END, text)
        self.query_var.set("")

    def remove_query(self):
        for i in reversed(self.query_list.curselection()):
            self.query_list.delete(i)

    def clear_queries(self):
        self.query_list.delete(0, tk.END)

    def get_queries(self) -> list[str]:
        if self.query_var.get().strip():
            self.add_query()
        return [self.query_list.get(i).strip() for i in range(self.query_list.size()) if self.query_list.get(i).strip()]

    def clear_results(self):
        if self.search_thread and self.search_thread.is_alive():
            return
        self.results = []
        for item in self.tree.get_children():
            self.tree.delete(item)
        self.export_btn.config(state="disabled")
        self.status_var.set("结果已清空")
        self.progress_var.set(0)
        self.abstract_translation_token += 1
        self._set_abstract("")
        self._set_abstract_translation("")
        if hasattr(self, "translation_status_var"):
            self.translation_status_var.set("")
        self._set_detail("")

    def _validate_year(self, value: str) -> bool:
        if not value:
            return True
        return value.isdigit() and 1800 <= int(value) <= 2100

    def load_if_file(self):
        path = filedialog.askopenfilename(
            title="选择影响因子表", filetypes=[("Excel/CSV", "*.xlsx *.xlsm *.csv"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            mapping = load_impact_factor_map(path)
            self.local_if_map = mapping
            self.if_file_var.set(path)
            messagebox.showinfo("影响因子表", f"已加载 {len(mapping)} 个期刊映射。")
        except Exception as exc:
            messagebox.showerror("加载失败", str(exc))

    def start_search(self):
        queries = self.get_queries()
        if not queries:
            messagebox.showwarning("缺少检索式", "请至少添加一个检索式。")
            return
        engines = [key for key, var in self.engine_vars.items() if var.get()]
        if not engines:
            messagebox.showwarning("缺少数据源", "请至少选择一个结构化数据源。")
            return
        start_year = self.start_year_var.get().strip()
        end_year = self.end_year_var.get().strip()
        if not self._validate_year(start_year) or not self._validate_year(end_year):
            messagebox.showwarning("年份错误", "年份应为 1800–2100 之间的四位数字，或留空。")
            return
        if start_year and end_year and int(start_year) > int(end_year):
            messagebox.showwarning("年份错误", "起始年份不能晚于结束年份。")
            return
        try:
            limit = min(500, max(5, int(self.limit_var.get())))
        except Exception:
            limit = 80
        self.limit_var.set(limit)
        try:
            min_citations = max(0, int(self.min_citations_var.get()))
        except Exception:
            min_citations = 0
        try:
            min_if = max(0.0, float(self.min_if_var.get()))
        except Exception:
            min_if = 0.0

        self._apply_rate_limits()
        sort_mode = self._sort_mode()
        self.cancel_event.clear()
        self.results = []
        for item in self.tree.get_children():
            self.tree.delete(item)
        self.export_btn.config(state="disabled")
        self.search_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        self.progress_var.set(0)
        self.status_var.set("正在检索…")
        self.abstract_translation_token += 1
        self._set_abstract("")
        self._set_abstract_translation("")
        if hasattr(self, "translation_status_var"):
            self.translation_status_var.set("")
        self._set_detail("")

        args = dict(
            queries=queries, engines=engines, limit=limit, start_year=start_year, end_year=end_year,
            min_citations=min_citations, min_if=min_if, sort_mode=sort_mode,
            strict_boolean=self.strict_boolean_var.get(), oa_only=self.oa_only_var.get(),
            pdf_only=self.pdf_only_var.get(), journal_only=self.journal_only_var.get(),
            journal_filter_text=self.journal_filter_var.get().strip(),
            openalex_key=self.openalex_key_var.get().strip(), semantic_key=self.semantic_key_var.get().strip(),
            crossref_email=self.crossref_email_var.get().strip(), wos_key=self.wos_key_var.get().strip(),
            serpapi_key=self.serpapi_key_var.get().strip(), use_unpaywall=self.unpaywall_var.get(),
            use_jcr=self.jcr_enrich_var.get(), jcr_key=self.jcr_key_var.get().strip(),
            jcr_year=self.jcr_year_var.get().strip(),
            bilingual_search=self.bilingual_search_var.get(), full_journal=self.full_journal_var.get(),
        )
        self.search_thread = threading.Thread(target=self._search_worker, kwargs=args, daemon=True)
        self.search_thread.start()

    def _sort_mode(self) -> str:
        value = self.sort_var.get()
        if value.startswith("年份"):
            return "year"
        if value == "引用次数":
            return "citations"
        if value == "影响因子":
            return "impact"
        return "relevance"

    def stop_search(self):
        self.cancel_event.set()
        self.status_var.set("正在停止；已发出的网络请求会先结束…")

    def _search_worker(self, queries, engines, limit, start_year, end_year, min_citations, min_if, sort_mode,
                       strict_boolean, oa_only, pdf_only, journal_only, journal_filter_text,
                       openalex_key, semantic_key, crossref_email, wos_key, serpapi_key,
                       use_unpaywall, use_jcr, jcr_key, jcr_year, bilingual_search, full_journal):
        translation_pairs: list[tuple[str, str]] = []
        if bilingual_search and not self.cancel_event.is_set():
            self.msg_queue.put(("status", "正在进行中英文互译并生成双语检索式…"))
            queries, translation_pairs = expand_bilingual_queries(queries)
            if translation_pairs:
                summary = "；".join(f"{a} → {b}" for a, b in translation_pairs[:3])
                if len(translation_pairs) > 3:
                    summary += f"；另 {len(translation_pairs)-3} 条"
                self.msg_queue.put(("status", f"双语检索式已生成：{summary}"))

        tasks = [(q, e) for q in queries for e in engines]
        total = len(tasks)
        done = 0
        all_papers: list[Paper] = []
        errors: list[str] = []

        def run_one(q: str, engine: str):
            if self.cancel_event.is_set():
                return []
            if engine == "openalex":
                return search_openalex(q, limit, start_year, end_year, openalex_key)
            if engine == "crossref":
                return search_crossref(q, limit, start_year, end_year, crossref_email)
            if engine == "semantic":
                return search_semantic_scholar(q, limit, start_year, end_year, semantic_key)
            if engine == "europepmc":
                return search_europe_pmc(q, limit, start_year, end_year)
            if engine == "arxiv":
                return search_arxiv(q, limit, start_year, end_year)
            if engine == "wos":
                return search_wos(q, limit, start_year, end_year, wos_key, sort_mode)
            if engine == "google_serpapi":
                return search_google_scholar_serpapi(q, limit, start_year, end_year, serpapi_key, sort_mode)
            return []

        max_workers = min(7, max(1, len(engines)))
        with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="literature") as executor:
            future_map = {executor.submit(run_one, q, e): (q, e) for q, e in tasks if not self.cancel_event.is_set()}
            for future in as_completed(future_map):
                q, engine = future_map[future]
                done += 1
                label = SEARCH_ENGINES[engine]
                try:
                    papers = future.result()
                    all_papers.extend(papers)
                    self.msg_queue.put(("progress", done, total, f"{label} / {q}: {len(papers)} 条"))
                except Exception as exc:
                    errors.append(f"{label} / {q}: {type(exc).__name__}: {exc}")
                    self.msg_queue.put(("progress", done, total, f"{label} 请求失败，继续其他数据源"))

        merged = merge_papers(all_papers)
        self.msg_queue.put(("status", f"初步去重 {len(merged)} 条；正在补充期刊全称/摘要/OA/JIF…"))

        if full_journal and not self.cancel_event.is_set():
            meta_errors = enrich_crossref_metadata(merged, crossref_email, self.cancel_event, openalex_key)
            errors.extend(meta_errors[:20])

        if use_unpaywall and crossref_email and not self.cancel_event.is_set():
            enrich_unpaywall(merged, crossref_email, self.cancel_event)

        if self.local_if_map and not self.cancel_event.is_set():
            apply_local_if_map(merged, self.local_if_map)

        if use_jcr and not self.cancel_event.is_set():
            if not jcr_key:
                errors.append("JCR enrich: 已勾选补充官方 JIF，但未填写 WoS Journals API Key")
            else:
                jcr_errors = enrich_jcr_impact_factor(merged, jcr_key, jcr_year, self.cancel_event)
                errors.extend(jcr_errors[:20])

        final = filter_and_sort_papers(
            merged, queries=queries, strict_boolean=strict_boolean, start_year=start_year, end_year=end_year,
            min_citations=min_citations, oa_only=oa_only, pdf_only=pdf_only,
            journal_filter_text=journal_filter_text, journal_only=journal_only, min_if=min_if, sort_mode=sort_mode,
        )
        self.msg_queue.put(("finished", final, errors, self.cancel_event.is_set()))

    def _poll_queue(self):
        try:
            while True:
                msg = self.msg_queue.get_nowait()
                kind = msg[0]
                if kind == "progress":
                    _, done, total, text = msg
                    self.progress_var.set((done / total * 100) if total else 0)
                    self.status_var.set(text)
                elif kind == "status":
                    self.status_var.set(msg[1])
                elif kind == "finished":
                    _, final, errors, cancelled = msg
                    self.results = final
                    self.table_sort_column = ""
                    self.table_sort_desc = False
                    self._render_results()
                    self._update_tree_sort_headings()
                    self.search_btn.config(state="normal")
                    self.stop_btn.config(state="disabled")
                    self.export_btn.config(state="normal" if final else "disabled")
                    if not cancelled:
                        self.progress_var.set(100)
                    self.status_var.set(
                        ("已停止" if cancelled else "完成") + f"：{len(final)} 条结果；失败/提示 {len(errors)} 个"
                    )
                    if errors:
                        detail = "\n\n".join(errors[:10])
                        if len(errors) > 10:
                            detail += f"\n\n……另有 {len(errors)-10} 个提示/错误"
                        messagebox.showwarning("部分数据源/增强步骤未完成", "其他结果已保留。\n\n" + detail)
        except queue.Empty:
            pass
        self.after(120, self._poll_queue)

    def _render_results(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        for idx, p in enumerate(self.results):
            if_text = f"{p.impact_factor:.3f}" if p.impact_factor is not None else ""
            cite_text = str(p.citation_count) if p.citation_count is not None else ""
            oa_text = "PDF" if p.pdf_url else ("OA" if (p.is_oa or p.oa_url) else "")
            self.tree.insert("", tk.END, iid=str(idx), values=(
                p.title, p.journal, p.year, if_text, cite_text, oa_text, p.doi, p.source, f"{p.relevance_score:.1f}"
            ))

    def _column_sort_value(self, paper: Paper, col: str):
        if col == "title":
            return clean_text(paper.title).casefold()
        if col == "journal":
            return clean_text(paper.journal).casefold()
        if col == "year":
            return int_or_none(paper.year)
        if col == "if":
            return paper.impact_factor
        if col == "citations":
            return paper.citation_count
        if col == "oa":
            return 2 if paper.pdf_url else (1 if (paper.is_oa or paper.oa_url) else 0)
        if col == "doi":
            return normalize_doi(paper.doi).casefold()
        if col == "source":
            return clean_text(paper.source).casefold()
        if col == "score":
            return paper.relevance_score
        return ""

    def _update_tree_sort_headings(self):
        for col, label in self.tree_headings.items():
            if col == self.table_sort_column:
                arrow = " ▼" if self.table_sort_desc else " ▲"
                self.tree.heading(col, text=label + arrow, command=lambda c=col: self.sort_results_by_column(c))
            else:
                self.tree.heading(col, text=label + " ↕", command=lambda c=col: self.sort_results_by_column(c))

    def sort_results_by_column(self, col: str):
        """Toggle ascending/descending sorting for any visible result column; keep missing values at the end."""
        if not self.results:
            return
        selected = self._selected_paper()
        if self.table_sort_column == col:
            self.table_sort_desc = not self.table_sort_desc
        else:
            self.table_sort_column = col
            self.table_sort_desc = False

        present: list[Paper] = []
        missing: list[Paper] = []
        for paper in self.results:
            value = self._column_sort_value(paper, col)
            if value is None or value == "":
                missing.append(paper)
            else:
                present.append(paper)
        present.sort(key=lambda p: self._column_sort_value(p, col), reverse=self.table_sort_desc)
        self.results = present + missing
        self._render_results()
        self._update_tree_sort_headings()

        if selected is not None:
            try:
                idx = next(i for i, p in enumerate(self.results) if p is selected)
                self.tree.selection_set(str(idx))
                self.tree.focus(str(idx))
                self.tree.see(str(idx))
            except StopIteration:
                pass
        direction = "降序" if self.table_sort_desc else "升序"
        self.status_var.set(f"表格排序：{self.tree_headings.get(col, col)} · {direction}（空值置后）")

    def _selected_paper(self) -> Optional[Paper]:
        sel = self.tree.selection()
        if not sel:
            return None
        try:
            return self.results[int(sel[0])]
        except Exception:
            return None

    def _set_text_widget(self, widget: tk.Text, text: str):
        widget.configure(state="normal")
        widget.delete("1.0", tk.END)
        widget.insert("1.0", text)
        widget.see("1.0")
        widget.configure(state="disabled")

    def _set_abstract(self, text: str):
        self._set_text_widget(self.abstract_text, text)

    def _set_abstract_translation(self, text: str):
        self._set_text_widget(self.abstract_translation_text, text)

    def _left_abstract_yset(self, first, last):
        self.abstract_scroll_left.set(first, last)
        if self.abstract_sync_scroll_var.get() and not self._syncing_abstract_scroll:
            try:
                self._syncing_abstract_scroll = True
                self.abstract_translation_text.yview_moveto(first)
            except Exception:
                pass
            finally:
                self._syncing_abstract_scroll = False

    def _right_abstract_yset(self, first, last):
        self.abstract_scroll_right.set(first, last)
        if self.abstract_sync_scroll_var.get() and not self._syncing_abstract_scroll:
            try:
                self._syncing_abstract_scroll = True
                self.abstract_text.yview_moveto(first)
            except Exception:
                pass
            finally:
                self._syncing_abstract_scroll = False

    def _scroll_left_abstract(self, *args):
        self.abstract_text.yview(*args)
        if self.abstract_sync_scroll_var.get():
            self.abstract_translation_text.yview(*args)

    def _scroll_right_abstract(self, *args):
        self.abstract_translation_text.yview(*args)
        if self.abstract_sync_scroll_var.get():
            self.abstract_text.yview(*args)

    def _on_abstract_mousewheel(self, event):
        units = int(-1 * (event.delta / 120)) if event.delta else 0
        if units:
            if self.abstract_sync_scroll_var.get():
                self.abstract_text.yview_scroll(units, "units")
                self.abstract_translation_text.yview_scroll(units, "units")
            else:
                event.widget.yview_scroll(units, "units")
        return "break"

    def _on_linux_abstract_wheel(self, widget: tk.Text, units: int):
        if self.abstract_sync_scroll_var.get():
            self.abstract_text.yview_scroll(units, "units")
            self.abstract_translation_text.yview_scroll(units, "units")
        else:
            widget.yview_scroll(units, "units")
        return "break"

    def _set_detail(self, text: str):
        self.detail_text.configure(state="normal")
        self.detail_text.delete("1.0", tk.END)
        self.detail_text.insert("1.0", text)
        self.detail_text.see("1.0")
        self.detail_text.configure(state="disabled")

    def _adjust_abstract_pane(self, delta: int):
        try:
            current = self.result_pane.sashpos(0)
            total = max(self.result_pane.winfo_height(), 300)
            new_pos = max(180, min(total - 220, current + delta))
            self.result_pane.sashpos(0, new_pos)
        except Exception:
            pass

    def _abstract_cache_key(self, abstract: str, target: str) -> tuple[str, str]:
        return (normalize_title(abstract), target)

    def _apply_translation_result(self, token: int, paper: Paper, source_lang: str, target: str, translated: str, provider: str):
        if token != self.abstract_translation_token:
            return
        current = self._selected_paper()
        if current is not paper:
            return
        if target == "zh":
            paper.abstract_en = paper.abstract if source_lang == "en" else translated
            paper.abstract_zh = translated if source_lang == "en" else paper.abstract
        else:
            paper.abstract_zh = paper.abstract if source_lang == "zh" else translated
            paper.abstract_en = translated if source_lang == "zh" else paper.abstract
        self.abstract_translation_cache[self._abstract_cache_key(paper.abstract, target)] = (translated, provider)
        self._set_abstract_translation(translated)
        self.translation_status_var.set(f"翻译完成 · {provider}")

    def _apply_translation_error(self, token: int, paper: Paper, message: str):
        if token != self.abstract_translation_token or self._selected_paper() is not paper:
            return
        self._set_abstract_translation("[自动翻译失败]\n\n" + message)
        self.translation_status_var.set("翻译失败")

    def _translate_selected_paper(self, paper: Paper, force: bool = False):
        abstract = (paper.abstract or "").strip()
        if not abstract:
            self._set_abstract_translation("[无原始摘要，无法翻译。]")
            self.translation_status_var.set("")
            return
        source_lang = detect_abstract_language(abstract)
        target = "en" if source_lang == "zh" else "zh"
        self.left_abs_title_var.set("中文原始摘要" if source_lang == "zh" else "English Original Abstract")
        self.right_abs_title_var.set("English Translation" if target == "en" else "中文自动翻译")

        if not self.abstract_auto_translate_var.get() and not force:
            self._set_abstract_translation("[自动翻译已关闭。点击“重新翻译”可立即翻译当前摘要。]")
            self.translation_status_var.set("自动翻译已关闭")
            return

        # Use paper-attached translation first, then shared cache.
        attached = paper.abstract_en if target == "en" else paper.abstract_zh
        if attached and not force and clean_text(attached) != clean_text(abstract):
            self._set_abstract_translation(attached)
            self.translation_status_var.set("已缓存")
            return
        key = self._abstract_cache_key(abstract, target)
        if key in self.abstract_translation_cache and not force:
            translated, provider = self.abstract_translation_cache[key]
            self._set_abstract_translation(translated)
            self.translation_status_var.set(f"已缓存 · {provider}")
            return

        self.abstract_translation_token += 1
        token = self.abstract_translation_token
        self._set_abstract_translation("正在自动翻译完整摘要……")
        self.translation_status_var.set("正在翻译…")
        baidu_appid = self.baidu_appid_var.get().strip()
        baidu_secret = self.baidu_secret_var.get().strip()
        libre_url = self.libre_url_var.get().strip()
        libre_key = self.libre_key_var.get().strip()
        deepl_key = self.deepl_key_var.get().strip()
        deepseek_key = self.deepseek_key_var.get().strip()
        model = self.deepseek_model_var.get().strip() or "deepseek-flash"

        def worker():
            try:
                translated, provider = translate_abstract_auto(
                    abstract,
                    target,
                    baidu_appid=baidu_appid,
                    baidu_secret=baidu_secret,
                    libre_url=libre_url,
                    libre_key=libre_key,
                    deepl_key=deepl_key,
                    deepseek_key=deepseek_key,
                    model=model,
                )
                self.after(0, self._apply_translation_result, token, paper, source_lang, target, translated, provider)
            except Exception as exc:
                self.after(0, self._apply_translation_error, token, paper, str(exc))

        threading.Thread(target=worker, daemon=True, name="abstract-translation").start()

    def retranslate_selected_abstract(self):
        p = self._selected_paper()
        if p:
            self._translate_selected_paper(p, force=True)

    def show_selected_abstract(self, _event=None):
        p = self._selected_paper()
        if not p:
            self.abstract_translation_token += 1
            self._set_abstract("")
            self._set_abstract_translation("")
            self._set_detail("")
            self.translation_status_var.set("")
            self.left_abs_title_var.set("原始摘要")
            self.right_abs_title_var.set("自动翻译")
            return
        abstract = p.abstract or "[当前数据源没有提供摘要元数据。可尝试勾选 Crossref 期刊全称/摘要补全，或改用 OpenAlex/Crossref 等数据源。]"
        self._set_abstract(abstract)
        if p.abstract:
            self._translate_selected_paper(p)
        else:
            self._set_abstract_translation("[无原始摘要，无法生成对应译文。]")
            self.translation_status_var.set("")
        detail = (
            f"题目：{p.title}\n"
            f"作者：{p.authors}\n"
            f"期刊全称：{p.journal}\n"
            f"年份：{p.year}    JIF：{p.impact_factor if p.impact_factor is not None else ''}    "
            f"引用：{p.citation_count if p.citation_count is not None else ''}\n"
            f"DOI：{p.doi}\n"
            f"官网：{p.official_url}\nPDF：{p.pdf_url}\nOA：{p.oa_url}\n"
            f"数据源：{p.source}\n"
            f"命中检索式：{p.query}"
        )
        self._set_detail(detail)

    def open_selected_official(self, _event=None):
        p = self._selected_paper()
        if p and p.official_url:
            webbrowser.open(p.official_url)

    def open_selected_pdf(self):
        p = self._selected_paper()
        if not p:
            return
        url = p.pdf_url or p.oa_url
        if url:
            webbrowser.open(url)
        else:
            messagebox.showinfo("没有 OA/PDF", "当前记录没有可用的 PDF/Open Access 链接。")

    def copy_selected_doi(self):
        p = self._selected_paper()
        if p and p.doi:
            self.clipboard_clear()
            self.clipboard_append(p.doi)
            self.status_var.set("DOI 已复制到剪贴板")

    def open_browser_searches(self):
        queries = self.get_queries()
        if not queries:
            messagebox.showwarning("缺少检索式", "请先添加检索式。")
            return
        sources = [k for k, v in self.browser_vars.items() if v.get()]
        if not sources:
            messagebox.showwarning("缺少网站", "请至少勾选一个网页检索平台。")
            return
        count = len(queries) * len([s for s in sources if s != "xmol"]) + (1 if "xmol" in sources else 0)
        if count > 12:
            ok = messagebox.askyesno("将打开较多标签页", f"本次可能打开约 {count} 个浏览器标签页，是否继续？")
            if not ok:
                return
        start_year = self.start_year_var.get().strip()
        end_year = self.end_year_var.get().strip()
        sort_mode = self._sort_mode()
        if self.bilingual_search_var.get():
            self.status_var.set("正在生成中英文网页检索式…")
            self.update_idletasks()
            queries, _pairs = expand_bilingual_queries(queries)
        for source in sources:
            if source == "xmol":
                self.clipboard_clear()
                self.clipboard_append(queries[0])
                webbrowser.open(browser_search_url(source, queries[0], start_year, end_year, sort_mode))
                continue
            for q in queries:
                url = browser_search_url(source, q, start_year, end_year, sort_mode)
                if url:
                    webbrowser.open_new_tab(url)
        self.status_var.set("已打开所选网页检索平台（含启用的中英文互译检索式）")

    def export_excel(self):
        if not self.results:
            messagebox.showinfo("没有结果", "当前没有可导出的文献记录。")
            return
        default_name = f"literature_v2_7_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
        path = filedialog.asksaveasfilename(
            title="保存 Excel", defaultextension=".xlsx", initialfile=default_name,
            filetypes=[("Excel 工作簿", "*.xlsx")],
        )
        if not path:
            return
        try:
            settings = {
                "排序": self.sort_var.get(),
                "年份范围": f"{self.start_year_var.get().strip() or '*'} - {self.end_year_var.get().strip() or '*'}",
                "仅OA": self.oa_only_var.get(),
                "仅PDF": self.pdf_only_var.get(),
                "指定期刊筛选": self.journal_filter_var.get() if self.journal_only_var.get() else "未启用",
                "中英文互译联合检索": self.bilingual_search_var.get(),
                "期刊全称/摘要补全": self.full_journal_var.get(),
                "摘要中英文双栏自动翻译": self.abstract_auto_translate_var.get(),
                "摘要翻译模型": self.deepseek_model_var.get() if self.deepseek_key_var.get().strip() else "公共翻译接口回退",
                "API限速配置": RATE_LIMIT_PROFILE_NAME + " | " + "; ".join(
                    f"{RATE_LIMIT_LABELS[k]}={v:.2f}s" for k, v in RATE_LIMIT_DEFAULTS.items()
                ),
            }
            export_xlsx(self.results, path, settings=settings)
            messagebox.showinfo("导出完成", f"已保存 {len(self.results)} 条记录：\n{path}")
        except Exception as exc:
            messagebox.showerror("导出失败", str(exc))


def main():
    app = LiteratureSearcherApp()
    app.mainloop()


if __name__ == "__main__":
    main()
