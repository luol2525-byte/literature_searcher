# Literature Searcher v2.7.0

## 内置 API 安全限速

本版将 v2.6 的“每个 API 手动填写访问间隔”改为**启动即启用的内置安全限速档**，普通用户无需配置。

内置最小请求间隔（秒/次）：

| API | 内置间隔 |
|---|---:|
| OpenAlex | 0.30 |
| Crossref | 1.10 |
| Semantic Scholar | 1.10 |
| Europe PMC | 0.50 |
| arXiv | 3.20 |
| Web of Science Starter | 1.10 |
| Google Scholar / SerpAPI | 1.50 |
| Unpaywall | 0.90 |
| WoS Journals / JCR | 0.30 |
| MyMemory | 1.00 |
| 百度翻译 | 1.10 |
| LibreTranslate | 1.00 |
| DeepL | 0.80 |
| DeepSeek | 0.50 |

这些数值是软件的保守安全档，不等同于所有账户的官方固定配额。API 服务商可能随时调整限制，软件仍以服务端 `Retry-After` 和实际 HTTP 状态为最高优先级。

### 防突发机制

- 同一 API 来源全局串行排队，多个检索线程不会同时冲击同一个服务。
- 不同 API 来源可并行，提高总体检索速度。
- `429 Too Many Requests` 自动遵守 `Retry-After`。
- `5xx` 自动指数退避并加入随机抖动。
- 来源级冷却：一个线程触发限流后，同来源其他线程同步等待。
- v2.6 保存过的手动限速值在 v2.7 中不会覆盖内置安全档。

